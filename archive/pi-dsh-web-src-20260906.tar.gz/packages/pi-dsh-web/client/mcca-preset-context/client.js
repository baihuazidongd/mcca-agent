/**
 * @mcca/pi-dsh-web — 预设上下文客户端插件。
 *
 * 两个表层：
 *   1. 设置页新小节「预设上下文」：预设（命名规则分组）的增删改 + 每个预设
 *      内规则的维护 + 「新会话默认启用」勾选 + AGENTS.md/CLAUDE.md 项目文件
 *      勾选 + 注入预览。
 *   2. 对话输入框工具行左侧的「预设」chip（conversation.input.left 槽位）：
 *      列出全部预设，勾选即写穿该会话的多选（可多选，可全不选），下一条
 *      消息生效。
 *
 * 形态与 vendor 客户端插件一致：`window.__ModuleLoader__.load({ id, factory })`，
 * factory 收到只能解析 seed 静态表单词的 require（这里只用 react）。工厂返回的
 * 函数插件面是 `{ inject: ["slots"], apply }`。
 *
 * 数据面走同源一元 RPC（客户端插件无法铸造自定义 remote 命名空间）：
 *   POST /api/presetContext.get     → { cwd, config, files, selected, preview }
 *   POST /api/presetContext.set     → { config }（服务端补齐 id 后回传）
 *   POST /api/presetContext.select  → { selected, preview }（会话级多选勾选）
 *
 * 交互约定：
 *   - AGENTS.md / CLAUDE.md 勾选 = 即时保存（勾选即写穿，下一条消息生效）；
 *   - 预设与规则的增删改 / 默认勾选 = 本地暂存，点「保存」整体提交；
 *   - chip 的会话勾选 = 即时保存（独立 RPC，只动该会话的勾选记录）；
 *   - 预设配置落盘在 pi 全局 agent 目录，跨工作区共用（不绑定任何仓库目录）。
 *
 * 启动安全：boot 扫描对任何抛错/挂起条目整体失败——factory 顶层不碰 DOM
 * （样式在 apply 里注入且幂等），RPC 全部在事件回调里发生，加载期零副作用。
 */
(function () {
  "use strict";

  /** 面板样式：class 全部 mpc- 前缀隔离；颜色只走 dsw 语义别名 token。 */
  const CSS = [
    ".mpc-section{display:flex;flex-direction:column;gap:14px;width:100%;max-width:760px;color:var(--dsw-alias-label-primary)}",
    ".mpc-intro,.mpc-empty,.mpc-muted{margin:0;font-size:13px;line-height:20px;color:var(--dsw-alias-label-tertiary)}",
    ".mpc-error{margin:0;font-size:13px;line-height:20px;color:var(--dsw-alias-state-error-primary)}",
    ".mpc-group{display:flex;flex-direction:column;gap:8px}",
    ".mpc-heading{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 2px}",
    ".mpc-heading h3{margin:0;font-size:13px;line-height:20px;font-weight:600}",
    ".mpc-cwd{overflow:hidden;min-width:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap}",
    ".mpc-file{display:flex;align-items:center;gap:10px;min-width:0;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:10px 14px;background:var(--dsw-alias-bg-base);cursor:pointer}",
    ".mpc-file:hover{background:var(--dsw-alias-interactive-bg-hover)}",
    ".mpc-file input[type=checkbox]{flex:none;margin:0}",
    ".mpc-file-label{flex:none;font-size:13px;line-height:20px;font-weight:600}",
    ".mpc-file-path{overflow:hidden;min-width:0;flex:1;font-size:12px;line-height:17px;color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap}",
    ".mpc-ws{display:flex;flex-direction:column;gap:4px;border:1px solid var(--dsw-alias-border-l1);border-radius:10px;padding:8px 12px;background:var(--dsw-alias-bg-base)}",
    ".mpc-ws[data-current='true']{border-color:var(--dsw-alias-state-business-primary)}",
    ".mpc-ws-head{display:flex;align-items:center;gap:8px;min-width:0}",
    ".mpc-ws-title{flex:none;font-size:12px;line-height:18px;font-weight:600;white-space:nowrap}",
    ".mpc-ws-path{overflow:hidden;min-width:0;flex:1;font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap}",
    ".mpc-ws-files{display:flex;flex-wrap:wrap;gap:6px;min-width:0}",
    ".mpc-ws-file{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--dsw-alias-border-l1);border-radius:999px;padding:1px 10px;font-size:11px;line-height:18px;color:var(--dsw-alias-label-tertiary)}",
    ".mpc-ws-file b{font-weight:600;color:var(--dsw-alias-label-secondary)}",
    ".mpc-badge{flex:none;border:1px solid var(--dsw-alias-border-l1);border-radius:999px;padding:1px 8px;font-size:11px;line-height:16px;color:var(--dsw-alias-label-secondary)}",
    ".mpc-badge-ok{color:var(--dsw-alias-state-business-primary)}",
    ".mpc-badge-missing{color:var(--dsw-alias-state-error-primary)}",
    ".mpc-preset{display:flex;flex-direction:column;gap:8px;border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:10px 14px;background:var(--dsw-alias-bg-base)}",
    ".mpc-preset-head{display:flex;align-items:center;gap:8px}",
    ".mpc-preset-name{min-width:0;flex:1;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:4px 10px;font-size:13px;line-height:20px;font-weight:600;background:var(--dsw-alias-bg-base);color:inherit}",
    ".mpc-default-check{display:flex;align-items:center;gap:5px;flex:none;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);cursor:pointer;white-space:nowrap}",
    ".mpc-default-check input{margin:0}",
    ".mpc-rule{display:flex;flex-direction:column;gap:8px;border:1px dashed var(--dsw-alias-border-l1);border-radius:8px;padding:8px 10px}",
    ".mpc-rule-head{display:flex;align-items:center;gap:8px}",
    ".mpc-rule-head input[type=checkbox]{flex:none;margin:0}",
    ".mpc-rule-name{min-width:0;flex:1;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:4px 10px;font-size:13px;line-height:20px;background:var(--dsw-alias-bg-base);color:inherit}",
    ".mpc-rule-content{resize:vertical;min-height:60px;border:1px solid var(--dsw-alias-border-l1);border-radius:8px;padding:6px 10px;font-family:inherit;font-size:12px;line-height:18px;background:var(--dsw-alias-bg-base);color:inherit}",
    ".mpc-footer{display:flex;align-items:center;justify-content:flex-end;gap:12px}",
    ".mpc-status{min-width:0;overflow:hidden;font-size:12px;line-height:17px;color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap}",
    ".mpc-status-error{color:var(--dsw-alias-state-error-primary)}",
    ".mpc-button{border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:4px 12px;font-size:12px;line-height:18px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);cursor:pointer}",
    ".mpc-button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}",
    ".mpc-button:disabled{cursor:not-allowed;opacity:.5}",
    ".mpc-button-primary{background:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary);color:#fff}",
    ".mpc-button-danger{color:var(--dsw-alias-state-error-primary)}",
    ".mpc-preview-details summary{cursor:pointer;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary);user-select:none}",
    ".mpc-preview{margin:8px 0 0;padding:10px 12px;max-height:320px;overflow:auto;border:1px solid var(--dsw-alias-border-l1);border-radius:10px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px;white-space:pre-wrap;word-break:break-word}",
    // —— 输入框旁的预设 chip（conversation.input.left 槽位） ——
    ".mpc-chip{display:inline-flex;align-items:center;gap:5px;max-width:220px;height:28px;padding:0 10px;border:1px solid var(--dsw-alias-border-l2);border-radius:999px;background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-secondary);font-size:12px;line-height:26px;cursor:pointer;white-space:nowrap}",
    ".mpc-chip:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}",
    ".mpc-chip[data-open='true']{border-color:var(--dsw-alias-border-l3);color:var(--dsw-alias-label-primary)}",
    ".mpc-chip[data-active='true']{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}",
    ".mpc-chip-icon{flex:none;font-size:12px;line-height:1}",
    ".mpc-chip-label{overflow:hidden;min-width:0;text-overflow:ellipsis}",
    ".mpc-chip-count{flex:none;min-width:16px;padding:0 5px;border-radius:999px;background:var(--dsw-alias-state-business-primary);color:#fff;font-size:10px;line-height:16px;text-align:center}",
    ".mpc-menu{position:fixed;z-index:1000;display:flex;flex-direction:column;min-width:240px;max-width:320px;max-height:320px;border:1px solid var(--dsw-alias-border-l2);border-radius:12px;background:var(--dsw-alias-bg-base);box-shadow:0 8px 28px rgba(0,0,0,.22);overflow:hidden}",
    ".mpc-menu-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 12px;border-bottom:1px solid var(--dsw-alias-border-l1);font-size:12px;line-height:18px;font-weight:600;color:var(--dsw-alias-label-primary)}",
    ".mpc-menu-hint{font-weight:400;color:var(--dsw-alias-label-tertiary)}",
    ".mpc-menu-list{display:flex;flex-direction:column;overflow:auto;padding:4px}",
    ".mpc-menu-item{display:flex;align-items:flex-start;gap:8px;width:100%;border:0;border-radius:8px;padding:6px 8px;background:transparent;color:var(--dsw-alias-label-primary);font-size:12px;line-height:18px;text-align:left;cursor:pointer}",
    ".mpc-menu-item:hover{background:var(--dsw-alias-interactive-bg-hover)}",
    ".mpc-menu-item input{flex:none;margin:2px 0 0}",
    ".mpc-menu-item-main{display:flex;flex-direction:column;gap:2px;min-width:0}",
    ".mpc-menu-item-name{font-weight:500}",
    ".mpc-menu-item-desc{overflow:hidden;color:var(--dsw-alias-label-tertiary);text-overflow:ellipsis;white-space:nowrap}",
    ".mpc-menu-empty{padding:12px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary)}",
  ].join("\n");

  /** 幂等注入样式（apply 阶段执行；重复挂载/HMR 不产生重复节点）。 */
  function ensureStyle() {
    try {
      if (typeof document === "undefined") return;
      if (document.querySelector('style[data-plugin="mcca-preset-context"]')) return;
      const style = document.createElement("style");
      style.setAttribute("data-plugin", "mcca-preset-context");
      style.setAttribute("data-plugin-css", "mcca-preset-context/client.css");
      style.textContent = CSS;
      document.head.appendChild(style);
    } catch {
      // 样式注入失败只影响观感，不阻断插件装配
    }
  }

  /** 同源一元 RPC：{ rpcId, payload } → wire.result（{ ok:true,value } / { ok:false,error }）。 */
  async function callBridge(method, payload) {
    const controller = typeof AbortController === "function" ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), 15000) : null;
    try {
      const res = await fetch(`/api/${method}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          rpcId: `mcca-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
          payload: payload || {},
        }),
        signal: controller ? controller.signal : undefined,
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const wire = await res.json();
      const result = wire && typeof wire === "object" ? wire.result : undefined;
      if (!result || result.ok !== true) {
        const error = result && result.error;
        throw new Error(
          error && error.message ? `${error.code || "internal"}: ${error.message}` : "服务端未返回有效结果"
        );
      }
      return result.value;
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
  }

  /** 规则数量文案（chip 菜单里的每项描述）。 */
  function presetSummary(preset) {
    const count = preset && Array.isArray(preset.rules) ? preset.rules.length : 0;
    return count ? `${count} 条规则` : "暂无规则，去设置里添加";
  }

  /** 服务端/本地配置 → UI 草稿的防御性拷贝（字段形态固定，但来源不可全信）。 */
  function cloneConfig(config) {
    const presets = config && Array.isArray(config.presets) ? config.presets : [];
    const defaultSelected = config && Array.isArray(config.defaultSelected) ? config.defaultSelected.filter((id) => typeof id === "string") : [];
    return {
      agentsMd: Boolean(config && config.agentsMd),
      claudeMd: Boolean(config && config.claudeMd),
      defaultSelected,
      presets: presets.map((preset) => ({
        id: preset && typeof preset.id === "string" ? preset.id : "",
        name: preset && typeof preset.name === "string" ? preset.name : "",
        rules: (preset && Array.isArray(preset.rules) ? preset.rules : []).map((rule) => ({
          id: rule && typeof rule.id === "string" ? rule.id : "",
          name: rule && typeof rule.name === "string" ? rule.name : "",
          content: rule && typeof rule.content === "string" ? rule.content : "",
          enabled: rule ? rule.enabled !== false : true,
        })),
      })),
    };
  }

  function formatSize(size) {
    if (typeof size !== "number" || !Number.isFinite(size) || size < 0) return "存在";
    if (size < 1024) return "存在 · <1 KB";
    return `存在 · ${(size / 1024).toFixed(1)} KB`;
  }

  window.__ModuleLoader__.load({
    id: "mcca-preset-context",
    factory: (require) => {
      const React = require("react");
      const h = React.createElement;

      /**
       * 设置小节主体：预设目录管理（分组 + 规则 + 默认勾选）。
       * props 里除框架派生项外还有 inject 面提供的 get/set（回调身份可能随
       * 渲染变化，故经 ref 访问，保证挂载取数 effect 只跑一次）。
       */
      function PresetContextSection(props) {
        const getRef = React.useRef(props.get);
        getRef.current = props.get;
        const setRef = React.useRef(props.set);
        setRef.current = props.set;

        const [loading, setLoading] = React.useState(true);
        const [loadError, setLoadError] = React.useState("");
        const [cwd, setCwd] = React.useState("");
        const [workspaces, setWorkspaces] = React.useState([]);
        const [preview, setPreview] = React.useState(null);
        const [draft, setDraft] = React.useState(cloneConfig(null));
        const [saving, setSaving] = React.useState(false);
        const [dirty, setDirty] = React.useState(false);
        const [status, setStatus] = React.useState({ kind: "none", text: "" });

        const load = React.useCallback(async () => {
          try {
            const value = await getRef.current({});
            setCwd(value && typeof value.cwd === "string" ? value.cwd : "");
            setWorkspaces(value && Array.isArray(value.workspaces) ? value.workspaces : []);
            setPreview(value && typeof value.preview === "string" ? value.preview : null);
            setDraft(cloneConfig(value && value.config));
            setLoadError("");
          } catch (error) {
            setLoadError(errorMessage(error));
          } finally {
            setLoading(false);
          }
        }, []);

        React.useEffect(() => {
          void load();
        }, [load]);

        /** 整包替换式保存：成功后用服务端回传的 config 重同步草稿。 */
        const save = React.useCallback(async (config) => {
          setSaving(true);
          try {
            const value = await setRef.current(config);
            setDraft(cloneConfig(value && value.config));
            setDirty(false);
            setStatus({ kind: "saved", text: "已保存，下一条消息生效" });
            try {
              const fresh = await getRef.current({});
              setCwd(fresh && typeof fresh.cwd === "string" ? fresh.cwd : "");
              setWorkspaces(fresh && Array.isArray(fresh.workspaces) ? fresh.workspaces : []);
              setPreview(fresh && typeof fresh.preview === "string" ? fresh.preview : null);
            } catch {
              // 预览刷新失败不影响保存结果；下次打开面板会重新取数
            }
          } catch (error) {
            setStatus({ kind: "error", text: `保存失败：${errorMessage(error)}` });
            setDirty(true);
          } finally {
            setSaving(false);
          }
        }, []);

        /** 本地编辑发生：标脏；上一次保存的报错随之让位给“有未保存的更改”。 */
        const touch = () => {
          setDirty(true);
          setStatus((prev) => (prev.kind === "error" ? { kind: "none", text: "" } : prev));
        };

        /** 文件勾选 = 即时保存（写穿设置文件，下一条消息生效）。 */
        const toggleFile = (key) => {
          const next = { ...draft, [key]: !draft[key] };
          setDraft(next);
          void save(cloneConfig(next));
        };

        const addPreset = () => {
          setDraft((prev) => ({
            ...prev,
            presets: [...prev.presets, { id: "", name: "", rules: [] }],
          }));
          touch();
        };

        const deletePreset = (index) => {
          setDraft((prev) => {
            const presets = prev.presets.filter((_, i) => i !== index);
            const gone = prev.presets[index];
            return {
              ...prev,
              presets,
              defaultSelected: gone && gone.id ? prev.defaultSelected.filter((id) => id !== gone.id) : prev.defaultSelected,
            };
          });
          touch();
        };

        const updatePreset = (index, patch) => {
          setDraft((prev) => ({
            ...prev,
            presets: prev.presets.map((preset, i) => (i === index ? { ...preset, ...patch } : preset)),
          }));
          touch();
        };

        /** 「新会话默认启用」勾选 = 维护 defaultSelected（本地暂存，随保存提交）。 */
        const toggleDefault = (presetId) => {
          setDraft((prev) => ({
            ...prev,
            defaultSelected: prev.defaultSelected.includes(presetId)
              ? prev.defaultSelected.filter((id) => id !== presetId)
              : [...prev.defaultSelected, presetId],
          }));
          touch();
        };

        const addRule = (presetIndex) => {
          setDraft((prev) => ({
            ...prev,
            presets: prev.presets.map((preset, i) =>
              i === presetIndex
                ? { ...preset, rules: [...preset.rules, { id: "", name: "", content: "", enabled: true }] }
                : preset
            ),
          }));
          touch();
        };

        const updateRule = (presetIndex, ruleIndex, patch) => {
          setDraft((prev) => ({
            ...prev,
            presets: prev.presets.map((preset, i) =>
              i === presetIndex
                ? { ...preset, rules: preset.rules.map((rule, j) => (j === ruleIndex ? { ...rule, ...patch } : rule)) }
                : preset
            ),
          }));
          touch();
        };

        const deleteRule = (presetIndex, ruleIndex) => {
          setDraft((prev) => ({
            ...prev,
            presets: prev.presets.map((preset, i) =>
              i === presetIndex ? { ...preset, rules: preset.rules.filter((_, j) => j !== ruleIndex) } : preset
            ),
          }));
          touch();
        };

        let statusText = "";
        if (status.kind === "error") statusText = status.text;
        else if (saving) statusText = "保存中…";
        else if (dirty) statusText = "有未保存的更改";
        else if (status.kind === "saved") statusText = status.text;

        if (loading) {
          return h("div", { className: "mpc-section" }, h("p", { className: "mpc-muted" }, "加载中…"));
        }

        if (loadError) {
          return h(
            "div",
            { className: "mpc-section" },
            h("p", { className: "mpc-error" }, `加载失败：${loadError}`),
            h(
              "button",
              {
                type: "button",
                className: "mpc-button",
                onClick: () => {
                  setLoadError("");
                  setLoading(true);
                  void load();
                },
              },
              "重试"
            )
          );
        }

        return h(
          "div",
          { className: "mpc-section" },
          h(
            "p",
            { className: "mpc-intro" },
            "预设是可复用的规则分组，保存在全局（跨工作区共用）。在对话输入框旁的「预设」按钮里按会话勾选要启用的预设（可多选）；勾选的规则会在每条消息发送时追加到系统提示词，保存后下一条消息立即生效。"
          ),

          h(
            "div",
            { className: "mpc-group" },
            h(
              "div",
              { className: "mpc-heading" },
              h("h3", null, "项目上下文文件（按工作区自动发现）"),
              cwd ? h("span", { className: "mpc-cwd", title: cwd }, `当前会话工作区：${cwd}`) : null
            ),
            h(
              "p",
              { className: "mpc-intro" },
              "开关是全局的：开启后，会话落在哪个工作区，就检查那个工作区里的文件，找到即作为上下文注入（每条消息现场解析，工作区之间互不影响）。"
            ),
            h("label", { key: "agentsMd", className: "mpc-file" },
              h("input", {
                type: "checkbox",
                checked: draft.agentsMd === true,
                disabled: saving,
                onChange: () => toggleFile("agentsMd"),
              }),
              h("span", { className: "mpc-file-label" }, "AGENTS.md"),
              h("span", { className: "mpc-file-path" }, "各工作区根目录；找到即注入")
            ),
            h("label", { key: "claudeMd", className: "mpc-file" },
              h("input", {
                type: "checkbox",
                checked: draft.claudeMd === true,
                disabled: saving,
                onChange: () => toggleFile("claudeMd"),
              }),
              h("span", { className: "mpc-file-label" }, "CLAUDE.md"),
              h("span", { className: "mpc-file-path" }, "各工作区根目录；找到即注入")
            ),
            workspaces.map((workspace) =>
              h(
                "div",
                { key: workspace.workspaceId || workspace.path, className: "mpc-ws", "data-current": workspace.current ? "true" : "false" },
                h(
                  "div",
                  { className: "mpc-ws-head" },
                  h("span", { className: "mpc-ws-title" }, workspace.current ? "● 当前" : workspace.title || "工作区"),
                  h("span", { className: "mpc-ws-path", title: workspace.path }, workspace.path)
                ),
                h(
                  "div",
                  { className: "mpc-ws-files" },
                  (workspace.files || []).map((file) =>
                    h(
                      "span",
                      { key: file.key, className: "mpc-ws-file" },
                      h("b", null, file.label),
                      file.exists ? `已找到 · ${formatSize(file.size)}` : "未找到"
                    )
                  )
                )
              )
            )
          ),

          h(
            "div",
            { className: "mpc-group" },
            h(
              "div",
              { className: "mpc-heading" },
              h("h3", null, "预设"),
              h(
                "button",
                { type: "button", className: "mpc-button", disabled: saving, onClick: addPreset },
                "+ 新建预设"
              )
            ),
            draft.presets.length === 0
              ? h("p", { className: "mpc-empty" }, "还没有预设；点「+ 新建预设」创建一个，再往里添加规则")
              : draft.presets.map((preset, presetIndex) =>
                  h(
                    "div",
                    { key: preset.id || `new-${presetIndex}`, className: "mpc-preset" },
                    h(
                      "div",
                      { className: "mpc-preset-head" },
                      h("input", {
                        type: "text",
                        className: "mpc-preset-name",
                        value: preset.name,
                        placeholder: "预设名称",
                        disabled: saving,
                        onChange: (event) => updatePreset(presetIndex, { name: event.target.value }),
                      }),
                      h(
                        "label",
                        { className: "mpc-default-check" },
                        h("input", {
                          type: "checkbox",
                          checked: preset.id ? draft.defaultSelected.includes(preset.id) : false,
                          disabled: saving || !preset.id,
                          onChange: () => toggleDefault(preset.id),
                        }),
                        "新会话默认启用"
                      ),
                      h(
                        "button",
                        {
                          type: "button",
                          className: "mpc-button mpc-button-danger",
                          disabled: saving,
                          onClick: () => deletePreset(presetIndex),
                        },
                        "删除预设"
                      )
                    ),
                    h(
                      "div",
                      { className: "mpc-heading" },
                      h("h3", null, "规则"),
                      h(
                        "button",
                        { type: "button", className: "mpc-button", disabled: saving, onClick: () => addRule(presetIndex) },
                        "+ 添加规则"
                      )
                    ),
                    preset.rules.length === 0
                      ? h("p", { className: "mpc-empty" }, "这个预设还没有规则")
                      : preset.rules.map((rule, ruleIndex) =>
                          h(
                            "div",
                            { key: rule.id || `new-${ruleIndex}`, className: "mpc-rule" },
                            h(
                              "div",
                              { className: "mpc-rule-head" },
                              h("input", {
                                type: "checkbox",
                                checked: rule.enabled,
                                disabled: saving,
                                "aria-label": `启用规则「${rule.name || "未命名"}」`,
                                onChange: () => updateRule(presetIndex, ruleIndex, { enabled: !rule.enabled }),
                              }),
                              h("input", {
                                type: "text",
                                className: "mpc-rule-name",
                                value: rule.name,
                                placeholder: "规则名称",
                                disabled: saving,
                                onChange: (event) => updateRule(presetIndex, ruleIndex, { name: event.target.value }),
                              }),
                              h(
                                "button",
                                {
                                  type: "button",
                                  className: "mpc-button mpc-button-danger",
                                  disabled: saving,
                                  onClick: () => deleteRule(presetIndex, ruleIndex),
                                },
                                "删除"
                              )
                            ),
                            h("textarea", {
                              className: "mpc-rule-content",
                              rows: 3,
                              value: rule.content,
                              placeholder: "规则内容（作为长期约束注入系统提示词）",
                              disabled: saving,
                              onChange: (event) => updateRule(presetIndex, ruleIndex, { content: event.target.value }),
                            })
                          )
                        )
                  )
                )
          ),

          h(
            "div",
            { className: "mpc-footer" },
            statusText
              ? h(
                  "span",
                  {
                    className:
                      status.kind === "error" && !saving && !dirty ? "mpc-status mpc-status-error" : "mpc-status",
                  },
                  statusText
                )
              : null,
            h(
              "button",
              {
                type: "button",
                className: "mpc-button mpc-button-primary",
                disabled: saving || !dirty,
                onClick: () => void save(cloneConfig(draft)),
              },
              saving ? "保存中…" : "保存"
            )
          ),

          h(
            "details",
            { className: "mpc-preview-details" },
            h("summary", null, "注入预览（假设当前会话勾选了全部预设）"),
            h("pre", { className: "mpc-preview" }, preview || "（当前没有启用任何注入项）")
          )
        );
      }

      /**
       * 输入框工具行的「预设」chip：多选勾选本会话要注入的预设。
       * owner 面是 InputZone（session 会话快照）；inject 面提供 load/select。
       */
      function PresetChip(props) {
        const loadRef = React.useRef(props.load);
        loadRef.current = props.load;
        const selectRef = React.useRef(props.select);
        selectRef.current = props.select;

        const sessionId = props.session && typeof props.session.sessionId === "string"
          ? props.session.sessionId
          : (typeof props.sessionId === "string" ? props.sessionId : "");

        const [open, setOpen] = React.useState(false);
        const [loading, setLoading] = React.useState(true);
        const [presets, setPresets] = React.useState([]);
        const [selected, setSelected] = React.useState([]);
        const [error, setError] = React.useState("");
        const buttonRef = React.useRef(null);
        const menuRef = React.useRef(null);
        const [menuPos, setMenuPos] = React.useState(null);

        /** 拉取预设目录与本会话勾选（打开菜单时也刷新，吃掉设置页的改动）。 */
        const refresh = React.useCallback(async () => {
          if (!sessionId) return;
          try {
            const value = await loadRef.current({ sessionId });
            const config = value && value.config && typeof value.config === "object" ? value.config : {};
            setPresets(Array.isArray(config.presets) ? config.presets : []);
            setSelected(value && Array.isArray(value.selected) ? value.selected : []);
            setError("");
          } catch (err) {
            setError(errorMessage(err));
          } finally {
            setLoading(false);
          }
        }, [sessionId]);

        React.useEffect(() => {
          void refresh();
        }, [refresh]);

        /** 打开时按按钮位置固定定位（工具行内联布局可能裁剪溢出，走 fixed）。 */
        const placeMenu = React.useCallback(() => {
          const button = buttonRef.current;
          if (!button) return;
          const rect = button.getBoundingClientRect();
          const width = 280;
          const left = Math.max(8, Math.min(rect.right - width, window.innerWidth - width - 8));
          setMenuPos({ left, bottom: Math.max(8, window.innerHeight - rect.top + 6) });
        }, []);

        const openMenu = () => {
          void refresh();
          placeMenu();
          setOpen(true);
        };

        const closeMenu = React.useCallback(() => setOpen(false), []);

        React.useEffect(() => {
          if (!open) return undefined;
          const onPointerDown = (event) => {
            const menu = menuRef.current;
            if (menu && menu.contains(event.target)) return;
            if (buttonRef.current && buttonRef.current.contains(event.target)) return;
            closeMenu();
          };
          const onKeyDown = (event) => {
            if (event.key === "Escape") closeMenu();
          };
          document.addEventListener("pointerdown", onPointerDown, true);
          document.addEventListener("keydown", onKeyDown, true);
          window.addEventListener("resize", closeMenu);
          return () => {
            document.removeEventListener("pointerdown", onPointerDown, true);
            document.removeEventListener("keydown", onKeyDown, true);
            window.removeEventListener("resize", closeMenu);
          };
        }, [open, closeMenu]);

        /** 勾选/取消一个预设：乐观更新 + 即时写穿（服务端持久化该会话勾选）。 */
        const togglePreset = (presetId) => {
          const next = selected.includes(presetId)
            ? selected.filter((id) => id !== presetId)
            : [...selected, presetId];
          const previous = selected;
          setSelected(next);
          if (!sessionId) return;
          void Promise.resolve(selectRef.current(sessionId, next)).then((value) => {
            if (value && Array.isArray(value.selected)) setSelected(value.selected);
          }).catch((err) => {
            setSelected(previous);
            setError(errorMessage(err));
          });
        };

        const activeCount = selected.filter((id) => presets.some((preset) => preset.id === id)).length;
        const menuStyle = menuPos
          ? { left: `${Math.round(menuPos.left)}px`, bottom: `${Math.round(menuPos.bottom)}px` }
          : { display: "none" };

        return h(
          "span",
          null,
          h(
            "button",
            {
              ref: buttonRef,
              type: "button",
              className: "mpc-chip",
              "data-open": open ? "true" : "false",
              "data-active": activeCount > 0 ? "true" : "false",
              "aria-haspopup": "menu",
              "aria-expanded": open,
              title: error
                ? `预设上下文（出错：${error}）`
                : "选择本会话启用的预设上下文（可多选）",
              onClick: () => (open ? closeMenu() : openMenu()),
            },
            h("span", { className: "mpc-chip-icon", "aria-hidden": "true" }, "▤"),
            h("span", { className: "mpc-chip-label" }, "预设"),
            activeCount > 0 ? h("span", { className: "mpc-chip-count" }, String(activeCount)) : null
          ),
          open
            ? h(
                "div",
                { ref: menuRef, className: "mpc-menu", style: menuStyle, role: "menu" },
                h(
                  "div",
                  { className: "mpc-menu-head" },
                  h("span", null, "预设上下文"),
                  h("span", { className: "mpc-menu-hint" }, "可多选，勾选即生效")
                ),
                h(
                  "div",
                  { className: "mpc-menu-list" },
                  presets.length === 0
                    ? h(
                        "div",
                        { className: "mpc-menu-empty" },
                        loading ? "加载中…" : "还没有预设。在 设置 → 预设上下文 里新建预设并添加规则。"
                      )
                    : presets.map((preset) =>
                        h(
                          "button",
                          {
                            key: preset.id,
                            type: "button",
                            className: "mpc-menu-item",
                            role: "menuitemcheckbox",
                            "aria-checked": selected.includes(preset.id),
                            onClick: () => togglePreset(preset.id),
                          },
                          h("input", {
                            type: "checkbox",
                            checked: selected.includes(preset.id),
                            readOnly: true,
                            tabIndex: -1,
                          }),
                          h(
                            "span",
                            { className: "mpc-menu-item-main" },
                            h("span", { className: "mpc-menu-item-name" }, preset.name || "未命名预设"),
                            h("span", { className: "mpc-menu-item-desc" }, presetSummary(preset))
                          )
                        )
                      )
                )
              )
            : null
        );
      }

      function apply(ctx) {
        ensureStyle();
        // settings.section 的声明方是 ui-settings-general；inject 会等声明出现、
        // 声明消失时回收本贡献、重新声明后重跑。
        ctx.slots.inject(
          "settings.section",
          () =>
            ctx.slots.register(
              {
                name: "settings.section",
                id: "preset-context",
                order: 16,
                label: () => "预设上下文",
                inject: () => ({
                  get: (payload) => callBridge("presetContext.get", payload),
                  set: (payload) => callBridge("presetContext.set", payload),
                }),
              },
              PresetContextSection
            )
        );
        // 输入框工具行左侧的预设多选 chip；声明方是 ui-conversation（编译进
        // shell 的槽位表），同样经 inject 等声明出现后挂入。
        ctx.slots.inject(
          "conversation.input.left",
          () =>
            ctx.slots.register(
              {
                name: "conversation.input.left",
                id: "preset-context-chip",
                inject: () => ({
                  load: (payload) => callBridge("presetContext.get", payload),
                  select: (sessionId, presetIds) =>
                    callBridge("presetContext.select", { sessionId, presetIds }),
                }),
              },
              PresetChip
            )
        );
      }

      return { inject: ["slots"], apply };
    },
  });
})();
