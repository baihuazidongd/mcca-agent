"use strict";

/**
 * @mcca/pi-dsh-web — pi 后端的 dsh 前端兼容层（骨架阶段）。
 *
 * 让 dsh 的 Web UI（apps/web 构建产物 + 43 个客户端插件 bundle）原样运行，
 * 后端协议面翻译到 pi（阶段③逐步接线）。骨架阶段交付：
 *   - dsh shell 静态服务 + window.__DSH_BOOT__ 注入（boot-reference.json）
 *   - /plugins/<id>/client.js 客户端 bundle 服务（从 vendor/dsh 解析包；
 *     mcca- 前缀的本仓库插件从 client/<id>/client.js 解析并动态追加进 boot 图）
 *   - /api 一元 RPC：host.describe 真实值；只读列表方法返回空态；
 *     其余返回结构化 not-implemented（前端面板各自处理）
 *   - presetContext.get/set/select：预设上下文（预设=命名规则分组，全局落盘 +
 *     会话级多选勾选），由 client/mcca-preset-context 的设置分区与输入框旁 chip 调用
 *   - /api/events.mux 与 /api/events.host 接受 WebSocket 连接并保持
 *
 * 运行：node packages/pi-dsh-web/server.cjs   （默认 :3458）
 */

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { createRequire } = require("node:module");
const { WebSocketServer } = require("ws");

const PORT = Number(process.env.MCCA_DSH_WEB_PORT) || 3458;

// 兼容层护栏：stdio 子进程/套接字的零星 EPIPE、扩展的未捕获异步错误
// 记录但不杀进程（dsh 宿主本身对下游错误也是隔离处理的）。
process.on("uncaughtException", (error) => {
  console.error("[pi-dsh-web] uncaught (suppressed):", error && error.message);
});
process.on("unhandledRejection", (reason) => {
  console.error("[pi-dsh-web] unhandled rejection (suppressed):", reason instanceof Error ? reason.message : String(reason));
});
const ROOT = path.resolve(__dirname, "..", "..");                       // D:\dshpi
const VENDOR = path.join(ROOT, "vendor", "dsh");                        // dsh 源码副本
const DIST = path.join(VENDOR, "apps", "web", "dist");                  // dsh 前端构建产物
const BOOT = JSON.parse(
  fs.readFileSync(path.join(__dirname, "boot-reference.json"), "utf8").replace(/^\uFEFF/, ""),
);

const MIME = {
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".woff2": "font/woff2",
};

// 解析锚点链：profile（用户安装的库插件）→ web-app bundle（内置客户端插件）→ vendor 根。
// pnpm 布局下每个包的依赖链接在“声明它的包”的 node_modules 里，单一锚点解析不全。
const RESOLVE_ANCHORS = [
  path.join(ROOT, "config", "dsh-home", "profiles", "web", "package.json"),
  path.join(VENDOR, "packages", "bundle", "web-app", "package.json"),
  path.join(VENDOR, "package.json"),
].map((anchor) => createRequire(anchor));

/** 客户端 bundle 解析缓存：entry id → 磁盘绝对路径或 null。 */
const clientBundleCache = new Map();
/** 本仓库自带的客户端插件（mcca- 前缀）扫描根：本地 client/ 目录优先，
 *  其次共享包目录 packages/client-plugins/（与 dsh profile 挂载同一份文件，
 *  双侧共用单一来源）。 */
const MCCA_CLIENT_DIR = path.join(__dirname, "client");
const MCCA_PLUGIN_DIR = path.join(ROOT, "packages", "client-plugins");
const MCCA_BUNDLE_DIRS = [MCCA_CLIENT_DIR, MCCA_PLUGIN_DIR];
function resolveMccaClientBundle(id) {
  if (!id.startsWith("mcca-")) return null;
  for (const dir of MCCA_BUNDLE_DIRS) {
    const file = path.join(dir, id, "client.js");
    if (fs.existsSync(file)) return file;
  }
  return null;
}
function resolveClientBundle(id) {
  if (clientBundleCache.has(id)) return clientBundleCache.get(id);
  let resolved = resolveMccaClientBundle(id);
  if (!resolved) {
    for (const requireAt of RESOLVE_ANCHORS) {
      try {
        resolved = requireAt.resolve(`${id}/client`);
        break;
      } catch {
        // 下一个锚点
      }
    }
  }
  clientBundleCache.set(id, resolved);
  return resolved;
}

/** bundle 内容指纹（12 位 sha256 前缀）：boot 图 rev 与 ?rev= 缓存穿透共用。 */
function bundleRev(content) {
  return crypto.createHash("sha256").update(content).digest("hex").slice(0, 12);
}

/**
 * 客户端插件开关（config/client-plugins.json 的 pi 段）。每次算 boot 图前查一次
 * 文件版本，mtime+size 未变就用缓存——开关改动下一个请求即生效，无需重启。
 */
const CLIENT_PLUGINS_CONFIG = path.join(ROOT, "config", "client-plugins.json");
let clientFlagsStamp = "";
let clientFlagsDisabled = new Set();
function piDisabledClientPlugins() {
  let stamp = "";
  try {
    const st = fs.statSync(CLIENT_PLUGINS_CONFIG);
    stamp = `${Math.round(st.mtimeMs)}-${st.size}`;
  } catch {
    clientFlagsStamp = "";
    clientFlagsDisabled = new Set();
    return clientFlagsDisabled;
  }
  if (stamp !== clientFlagsStamp) {
    clientFlagsStamp = stamp;
    try {
      const raw = JSON.parse(fs.readFileSync(CLIENT_PLUGINS_CONFIG, "utf8").replace(/^﻿/, ""));
      const pi = raw && typeof raw.pi === "object" && raw.pi !== null ? raw.pi : {};
      clientFlagsDisabled = new Set(Object.keys(pi).filter((id) => pi[id] === false));
    } catch {
      clientFlagsDisabled = new Set(); // 坏配置按“全启用”处理
    }
  }
  return clientFlagsDisabled;
}

/**
 * mcca- 前缀客户端插件的 boot 条目：**每次响应现算**（不是启动时冻结），所以
 * 新增 / 删除 / 修改插件目录都即时生效，刷新页面即可，无需重启进程。
 * rev 按文件内容算，并以 `mtime-size` 作缓存键，避免每次响应都重哈希。
 * 扫描根：packages/pi-dsh-web/client 与 packages/client-plugins；同 id 先扫到的
 * 根为准；与 vendor 行同 id 时让位给 vendor 行；被开关禁用的 id 直接不进图。
 */
const mccaEntryCache = new Map();
function mccaBootEntries() {
  const entries = [];
  const seen = new Set();
  const disabled = piDisabledClientPlugins();
  for (const dir of MCCA_BUNDLE_DIRS) {
    let dirEntries = [];
    try {
      dirEntries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const dirent of dirEntries.sort((a, b) => a.name.localeCompare(b.name))) {
      if (!dirent.isDirectory() || !dirent.name.startsWith("mcca-")) continue;
      const dirName = dirent.name;
      // 行 id 优先取 package.json 的 name：dsh 的客户端行本就按包名键控，两边
      // 同键之后 bundle 只需注册一个 id。URL 仍用目录名，/plugins/<目录名> 的
      // 解析路径不变。
      let id = dirName;
      try {
        const pkg = JSON.parse(fs.readFileSync(path.join(dir, dirName, "package.json"), "utf8").replace(/^﻿/, ""));
        if (typeof pkg.name === "string" && pkg.name) id = pkg.name;
      } catch {
        // 无 package.json 的本地 bundle 按目录名键控
      }
      if (disabled.has(id) || disabled.has(dirName)) continue;
      if (seen.has(id) || BOOT.entries.some((entry) => entry.id === id)) continue;
      const file = path.join(dir, dirName, "client.js");
      let stat;
      try {
        stat = fs.statSync(file);
      } catch {
        continue; // 目录在扫描瞬间被删：本轮跳过，下轮自然消失
      }
      const stamp = `${Math.round(stat.mtimeMs)}-${stat.size}`;
      let cached = mccaEntryCache.get(id);
      if (cached === undefined || cached.stamp !== stamp) {
        const rev = bundleRev(fs.readFileSync(file, "utf8"));
        cached = {
          stamp,
          entry: { id, url: `/plugins/${dirName}/client.js?rev=${rev}`, rev, inject: [], immediately: false },
        };
        mccaEntryCache.set(id, cached);
      }
      seen.add(id);
      entries.push(cached.entry);
    }
  }
  for (const id of [...mccaEntryCache.keys()]) {
    if (!seen.has(id)) mccaEntryCache.delete(id);
  }
  return entries;
}

function send(res, status, type, body) {
  res.writeHead(status, { "content-type": type, "cache-control": "no-store" });
  res.end(body);
}

function sendJson(res, status, value) {
  send(res, status, "application/json; charset=utf-8", JSON.stringify(value));
}

/** dsh 一元 RPC 应答包络。 */
function ok(value) {
  return { ok: true, value };
}
/** dsh 客户端 zod 校验接受的 RPC 错误码全集（rpc.ts 的错误码表）。 */
const RPC_ERROR_CODES = new Set([
  "bad-request", "cancelled", "session-not-found", "model-unavailable", "session-conflict",
  "invalid-time-zone", "workspace-attach-failed", "workspace-not-found", "workspace-invalid-path",
  "workspace-name-conflict", "workspace-move-invalid", "directory-unreadable", "directory-exists",
  "directory-create-failed", "directory-picker-unavailable", "agent-preset-read-only",
  "agent-preset-locked", "agent-preset-conflict", "agent-preset-not-found", "agent-preset-invalid",
  "agent-busy", "attachment-error", "queue-item-not-found", "steer-unavailable", "command-error",
  "unknown-command", "settings-rejected", "settings-not-exposed", "settings-conflict",
  "credential-rejected", "model-discovery-failed", "title-invalid", "fork-unavailable",
  "subagent-parent-unavailable", "subagent-not-found", "subagent-catalog-diagnostic",
  "subagent-not-resumable", "subagent-unauthorized", "subagent-delivery-unavailable", "internal",
]);

/**
 * 错误码 → details 必需字段合成器（RpcErrorDetailsMap 的运行时镜像）：
 * 传入的 details 字段优先，缺失字段按表补缺省值——错误响应形态永远合规。
 */
const ERROR_DETAILS_BUILDERS = {
  "bad-request": (d) => ({ issues: d.issues ?? [] }),
  "session-not-found": (d) => ({ sessionId: d.sessionId ?? "" }),
  "model-unavailable": (d) => ({ provider: d.provider ?? "", model: d.model ?? "" }),
  "session-conflict": (d) => ({ sessionId: d.sessionId ?? "", requestedCwd: d.requestedCwd ?? "" }),
  "invalid-time-zone": (d) => ({ value: d.value ?? "" }),
  "workspace-attach-failed": (d) => ({ sessionId: d.sessionId ?? "", workspaceId: d.workspaceId ?? "" }),
  "workspace-not-found": (d) => ({ workspaceId: d.workspaceId ?? "" }),
  "workspace-invalid-path": (d) => ({ path: d.path ?? "" }),
  "workspace-name-conflict": (d) => ({ name: d.name ?? "" }),
  "workspace-move-invalid": (d) => ({ workspaceId: d.workspaceId ?? "", sessionId: d.sessionId ?? "" }),
  "directory-unreadable": (d) => ({ path: d.path ?? "" }),
  "directory-exists": (d) => ({ path: d.path ?? "" }),
  "directory-create-failed": (d) => ({ path: d.path ?? "" }),
  "directory-picker-unavailable": (d) => ({ capability: d.capability ?? "pickDirectory" }),
  "agent-preset-read-only": (d) => ({ agentPreset: d.agentPreset ?? "", reason: d.reason ?? "" }),
  "agent-preset-locked": (d) => ({ sessionId: d.sessionId ?? "", agentPreset: d.agentPreset ?? "" }),
  "agent-preset-conflict": (d) => ({ sessionId: d.sessionId ?? "", requestedPreset: d.requestedPreset ?? "" }),
  "agent-preset-not-found": (d) => ({ agentPreset: d.agentPreset ?? "", available: d.available ?? [] }),
  "agent-preset-invalid": (d) => ({ agentPreset: d.agentPreset ?? "", reason: d.reason ?? "" }),
  "agent-busy": (d) => ({ reason: d.reason ?? "" }),
  "attachment-error": (d) => ({ reason: d.reason ?? "" }),
  "queue-item-not-found": (d) => ({ itemId: d.itemId ?? "" }),
  "steer-unavailable": (d) => ({ itemId: d.itemId ?? "" }),
  "settings-rejected": (d) => ({ ns: d.ns ?? "" }),
  "settings-not-exposed": (d) => ({ ns: d.ns ?? "" }),
  "settings-conflict": (d) => ({ ns: d.ns ?? "", expected: d.expected ?? 0, actual: d.actual ?? 0 }),
  "credential-rejected": (d) => ({ ref: d.ref ?? "" }),
  "model-discovery-failed": (d) => ({ settingsNs: d.settingsNs ?? "" }),
  "title-invalid": (d) => ({ sessionId: d.sessionId ?? "" }),
  "fork-unavailable": (d) => ({ sessionId: d.sessionId ?? "" }),
  "subagent-parent-unavailable": (d) => ({ parentSessionId: d.parentSessionId ?? "" }),
  "subagent-not-found": (d) => ({ parentSessionId: d.parentSessionId ?? "", childSessionId: d.childSessionId ?? "" }),
  "subagent-catalog-diagnostic": (d) => ({ parentSessionId: d.parentSessionId ?? "", childSessionId: d.childSessionId ?? "", reason: d.reason ?? "unavailable" }),
  "subagent-not-resumable": (d) => ({ childSessionId: d.childSessionId ?? "" }),
  "subagent-unauthorized": (d) => ({ childSessionId: d.childSessionId ?? "" }),
  "subagent-delivery-unavailable": (d) => ({ childSessionId: d.childSessionId ?? "" }),
};

function rpcError(code, message, details) {
  // 非白名单错误码会被客户端的响应校验整包拒收——统一降级为 internal。
  const safeCode = RPC_ERROR_CODES.has(code) ? code : "internal";
  const base = details && typeof details === "object" ? details : {};
  // details 形态按码合成（每码有专属必需字段），传入字段优先。
  const synthesized = ERROR_DETAILS_BUILDERS[safeCode] ? ERROR_DETAILS_BUILDERS[safeCode](base) : {};
  return { ok: false, error: { code: safeCode, message, details: { ...synthesized, ...base } } };
}

// ── /api 一元方法表（阶段③：会话 MVP 已接 pi 桥） ──────────────────

const { PiBridge } = require("./pi-bridge.cjs");
const bridge = new PiBridge();

const API_METHODS = {
  "host.describe": () => ok({
    version: "0.1.0-pi-bridge",
    cwd: ROOT,
    attachedSessions: bridge.sessions.size,
    canOpenPath: false,
  }),
  "host.listDirectory": (body) => callBridge(body, (payload) => bridge.listDirectory(payload)),
  "host.createDirectory": (body) => callBridge(body, (payload) => bridge.createDirectory(payload)),
  "host.pickDirectory": (body) => callBridge(body, () => bridge.pickDirectory()),
  "host.openPath": (body) => callBridge(body, () => bridge.openPath()),

  // —— 会话 MVP（pi 桥） ——
  "session.create": (body) => callBridge(body, (payload) => bridge.createSession(payload)),
  "session.list": () => callBridge(null, () => bridge.listSessions()),
  "session.history": (body) => callBridge(body, (payload) => bridge.history(payload)),
  "session.models": (body) => callBridge(body, (payload) => bridge.sessionModels(payload)),
  "session.prompt": (body) => callBridge(body, (payload) => bridge.prompt(payload)),
  "session.cancel": (body) => callBridge(body, (payload) => bridge.cancel(payload)),
  "session.rename": (body) => callBridge(body, (payload) => bridge.rename(payload)),
  "session.fork": (body) => callBridge(body, (payload) => bridge.forkSession(payload)),
  "session.selectModel": (body) => callBridge(body, (payload) => bridge.selectModel(payload)),
  "settings.describe": (body) => callBridge(body, () => bridge.settingsDescribe()),
  "settings.mutate": (body) => callBridge(body, (payload) => bridge.settingsMutate(payload)),
  "agentPreset.list": (body) => callBridge(body, () => bridge.agentPresetList()),
  "agentPreset.select": (body) => callBridge(body, (payload) => bridge.agentPresetSelect(payload)),
  "workspace.list": (body) => callBridge(body, () => bridge.workspaceList()),
  "workspace.rename": (body) => callBridge(body, (payload) => bridge.workspaceRename(payload)),
  "workspace.create": (body) => callBridge(body, (payload) => bridge.workspaceCreate(payload)),
  "workspace.delete": (body) => callBridge(body, (payload) => bridge.workspaceDelete(payload)),
  "workspace.insertBefore": (body) => callBridge(body, (payload) => bridge.workspaceInsertBefore(payload)),
  "workspace.insertSessionBefore": (body) => callBridge(body, (payload) => bridge.workspaceInsertSessionBefore(payload)),
  "workspace.archiveSession": (body) => callBridge(body, (payload) => bridge.archiveSession(payload)),
  "workspace.unarchiveSession": (body) => callBridge(body, (payload) => bridge.unarchiveSession(payload)),
  "llm.providers": () => callBridge(null, () => bridge.llmProviders()),
  "llm.models": () => callBridge(null, () => bridge.llmModels()),
  "llm.discoverModels": (body) => callBridge(body, (payload) => bridge.llmDiscoverModels(payload)),
  "credentials.describe": (body) => callBridge(body, (payload) => bridge.credentialsDescribe(payload)),
  "credentials.set": (body) => callBridge(body, (payload) => bridge.credentialsSet(payload)),
  "credentials.unset": (body) => callBridge(body, (payload) => bridge.credentialsUnset(payload)),

  // —— 空态只读面 ——
  "session.search": () => ok({ items: [], hasMore: false }),
  // 子代理面（pi-subagents 扩展在 agent 内部；桥层目录空态起步）。
  "subagent.list": (body) => callBridge(body, (payload) => bridge.subagentList(payload)),
  "subagent.history": (body) => callBridge(body, (payload) => bridge.subagentHistory(payload)),
  "subagent.prompt": (body) => callBridge(body, (payload) => bridge.subagentPrompt(payload)),
  "subagent.interrupt": (body) => callBridge(body, (payload) => bridge.subagentInterrupt(payload)),
  // —— 技能目录（composer 的 / 菜单）：pi 桥真数据 ——
  "skill.list": (body) => callBridge(body, (payload) => bridge.skillList(payload)),
  // —— 预设上下文（settings 的「预设上下文」分区 + 输入框旁的预设多选 chip）：
  // 预设目录读写 + 会话勾选 + 注入预览 ——
  "presetContext.get": (body) => callBridge(body, (payload) => bridge.presetContextGet(payload)),
  "presetContext.set": (body) => callBridge(body, (payload) => bridge.presetContextSet(payload)),
  "presetContext.select": (body) => callBridge(body, (payload) => bridge.presetContextSelect(payload)),
};

/** 解析 Typert remote 请求（args + agentId），桥调用统一错误包络。 */
async function callGoal(rawBody, fn) {
  let args = {};
  let sessionId = "";
  try {
    const parsed = JSON.parse(rawBody || "{}");
    const p = parsed?.payload;
    args = p?.args && typeof p.args === "object" ? p.args : {};
    sessionId = String(args?.agentId ?? "");
  } catch {
    args = {};
  }
  try {
    const value = await fn(args, sessionId);
    if (value && typeof value === "object" && value.ok === false) {
      const error = value.error || {};
      return rpcError(error.code || "internal", error.message || "bridge error", error.details);
    }
    return ok(value);
  } catch (error) {
    return rpcError("internal", error instanceof Error ? error.message : String(error));
  }
}

/** 解析请求体里的 payload 并调用桥方法，统一错误包络。 */
async function callBridge(rawBody, fn) {  let payload = {};
  try {
    const parsed = JSON.parse(rawBody || "{}");
    payload = parsed && typeof parsed.payload === "object" && parsed.payload ? parsed.payload : {};
  } catch {
    payload = {};
  }
  try {
    const value = await fn(payload);
    // 桥以 RpcResponse 形态表达业务失败（保留 code+details）：透传为顶层错误。
    if (value && typeof value === "object" && value.ok === false) {
      const error = value.error || {};
      return rpcError(error.code || "internal", error.message || "bridge error", error.details);
    }
    return ok(value);
  } catch (error) {
    return rpcError("internal", error instanceof Error ? error.message : String(error));
  }
}

// ── Typert remote 面：POST /api/<namespace>/<method>，args 在 payload.args ──
// 一元方法表未命中时落到这里；不认识的 remote 同样回结构化错误。

const REMOTE_METHODS = {
  "commands/execute": (body) => {
    let args = {};
    try {
      const parsed = JSON.parse(body || "{}");
      args = parsed?.payload?.args && typeof parsed.payload.args === "object" ? parsed.payload.args : {};
    } catch {
      args = {};
    }
    return bridge.executeCommand(args);
  },
  // 命令发现面板：pi 桥映射的斜杠命令描述符（与 executeCommand 的 switch 对齐；
  // wire 形态为裸 CommandDescriptor[]，按 agentId 会话各取一份）。
  // ⚠️ 不与宿主内置命令同名（如 model），避免 UI 因 collision 阻塞整个菜单。
  "commands/list": () => [
    { name: "compact", description: "压缩会话上下文" },
    { name: "clear", description: "清空待发队列" },
    { name: "title", description: "设置会话标题", input: { hint: "<新标题>" } },
    { name: "goal", description: "设置或查看长期任务目标", input: { hint: "[<目标>|edit <目标>|pause|resume|clear|relentless|normal]" } },
  ],
  // 客户端 cordis 组合面：pi 桥无动态插件宿主行，与真宿主空态一致。
  "dynamicCordisRunner/inventory": () => [],
  "dynamicCordisRunner/syncInspectManifest": () => null,
  // goal 面：目标驱动循环（含 relentless 强制完成模式）。
  // Typert args：{agentId, objective, maxGoalRounds?, mode?}（agentId 即会话 id）。
  "goal/create": (body) => callGoal(body, (args, sid) => bridge.goalCreate(args, sid)),
  "goal/edit": (body) => callGoal(body, (args, sid) => bridge.goalEdit(args, sid)),
  "goal/pause": (body) => callGoal(body, (args, sid) => bridge.goalPause(args, sid)),
  "goal/resume": (body) => callGoal(body, (args, sid) => bridge.goalResume(args, sid)),
  "goal/complete": (body) => callGoal(body, (args, sid) => bridge.goalComplete(args, sid)),
  "goal/clear": (body) => callGoal(body, (args, sid) => bridge.goalClear(args, sid)),

  // —— 目录 remote 面：共享插件库 / 技能库 / MCP 注册表 ──────────────
  // wire 形态对齐真宿主的 Typert remote：POST /api/<ns>/<method>，
  // args 在 payload.args。gateway 的返回形态是 {ok:true, value} /
  // {ok:false, error}；未知名称（skillInventory/get）返回 {ok:true}
  // 不带 value——分发层对含 ok 键的返回值原样透传，不会被补包 value。
  "pluginInventory/list": () => bridge.pluginInventoryList(),
  "pluginInventory/setEnabled": async (body) => {
    const request = parseRemoteArgs(body, "request");
    return bridge.pluginInventorySetEnabled(request);
  },
  "skillInventory/list": () => bridge.skillInventoryList(),
  "skillInventory/get": (body) => {
    const request = parseRemoteArgs(body, "request");
    const detail = bridge.skillInventoryGet(request);
    return detail === undefined ? { ok: true } : { ok: true, value: detail };
  },
  "skillInventory/setEnabled": (body) => {
    const request = parseRemoteArgs(body, "request");
    return bridge.skillInventorySetEnabled(request);
  },
  "mcpInventory/list": () => bridge.mcpInventoryList(),
  "mcpInventory/setEnabled": async (body) => {
    const request = parseRemoteArgs(body, "request");
    return bridge.mcpInventorySetEnabled(request);
  },
};

/** 解析 Typert remote 请求体的 args.<field>（wire 形态：payload.args）。 */
function parseRemoteArgs(body, field) {
  try {
    const parsed = JSON.parse(body || "{}");
    const args = parsed?.payload?.args;
    if (args && typeof args === "object" && args[field] && typeof args[field] === "object") {
      return args[field];
    }
  } catch {
    // 缺失/畸形 args 按空请求处理；各桥方法自行校验必需字段
  }
  return {};
}

function notImplemented(method) {
  return rpcError("internal", `pi compat layer: ${method} is not wired yet`);
}

// ── 静态：shell + boot 注入 ────────────────────────────────────────

function shellHtml() {
  const index = fs.readFileSync(path.join(DIST, "index.html"), "utf8");
  const boot = `<script>window.__DSH_BOOT__ = ${JSON.stringify({ ...BOOT, entries: [...BOOT.entries, ...mccaBootEntries()] })};</script>`;
  // 品牌改写：页签标题 DeepSeek Harness → pi。
  const branded = index.replace("<title>DeepSeek Harness</title>", "<title>pi</title>");
  // 诊断上报（轻量版）：浏览器端未捕获错误/rejection 上报 /mcca/diag。
  // 调试期的 console.error 劫持与 3s DOM 轮询（composer 渲染排查用）已摘除。
  const diag = `<script>(function () { function post(kind, data) { try { fetch("/mcca/diag", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind: kind, data: data }) }); } catch (e) {} } window.addEventListener("error", function (ev) { post("error", { message: String(ev.message), source: String(ev.filename || "") + ":" + (ev.lineno || 0), stack: ev.error && ev.error.stack ? String(ev.error.stack).slice(0, 1500) : "" }); }); window.addEventListener("unhandledrejection", function (ev) { post("rejection", { message: String(ev.reason && (ev.reason.message || ev.reason) || "unknown") }); }); })();</script>`;
  // 品牌文字注入：运行时把 wordmark（182x24）换成文字 "pi dome"，
  // FishLogo（23.16x17.04）换成 "pi"——DOM 层替换，不碰压缩 JSX。
  const brandDom = `<script>(function () {
  function toText(svg, str, fs, cx) {
    if (!svg || svg.getAttribute("data-pi-brand") === "1") return;
    svg.setAttribute("data-pi-brand", "1");
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    var t = document.createElementNS("http://www.w3.org/2000/svg", "text");
    t.setAttribute("x", cx); t.setAttribute("y", "50%");
    t.setAttribute("dominant-baseline", "central");
    t.setAttribute("fill", "currentColor");
    t.setAttribute("font-size", fs);
    t.setAttribute("font-weight", "700");
    t.setAttribute("letter-spacing", "0.5");
    t.setAttribute("font-family", "system-ui, -apple-system, sans-serif");
    t.textContent = str;
    svg.appendChild(t);
  }
  function scan() {
    var marks = document.querySelectorAll('svg[viewBox="0 0 182 24"]');
    for (var i = 0; i < marks.length; i++) toText(marks[i], "pi EAs", 20, 6);
    var fish = document.querySelectorAll('svg[viewBox="0 0 23.16 17.04"]');
    for (var j = 0; j < fish.length; j++) toText(fish[j], "pi", 14, 2);
  }
  try {
    new MutationObserver(function () { scan(); }).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scan);
  } else { scan(); }
})();</script>`;
  // dsh 宿主在 <head> 后注入 boot script（先于 vite 入口 module script 求值）。
  return branded.replace("<head>", `<head>${brandDom}${diag}${boot}`);
}

/** pi 品牌的 π favicon（替换 DeepSeek 的 favicon.svg 响应）。 */
function piFavicon() {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23.16 17.04"><path fill="#4D6BFE" d="${PI_MARK}"/></svg>`;
}

// ── 品牌改写：shell 里的 DeepSeek 鱼 logo → pi 的 π 图形 ──────────
// 原始 path 长串存于 brand-paths.json（从 shell bundle 精确提取）；
// 改写仅发生在 3458 的响应层，vendor 源与 3081 真 dsh 不受影响。

// pi 字母形两版：
// PI_MARK —— FishLogo 位（viewBox 0 0 23.16 17.04：侧栏 rail / hero），居中。
// PI_MARK_WORDMARK —— wordmark 鲸位兜底图形（主显示为 DOM 文字注入 "pi dome"）。
const PI_MARK = "M5.9 2h2v14h-2Z M5.9 2h8v2h-8Z M11.9 2h2v8h-2Z M5.9 8h8v2h-8Z M17.9 2h2v2.4h-2Z M17.9 6.4h2v9.6h-2Z";
const PI_MARK_WORDMARK = "M4 2h2.2v15.5h-2.2Z M4 6h7.3v2.2h-7.3Z M9.1 6h2.2v9.5h-2.2Z M4 13.3h7.3v2.2h-7.3Z M16 2h2.2v2.2h-2.2Z M16 6h2.2v11.5h-2.2Z";

let brandRewrites = null;
function loadBrandRewrites() {
  if (brandRewrites !== null) return brandRewrites;
  brandRewrites = [];
  try {
    const raw = JSON.parse(
      fs.readFileSync(path.join(__dirname, "brand-paths.json"), "utf8").replace(/^\uFEFF/, ""),
    );
    if (raw.fish) brandRewrites.push([raw.fish, PI_MARK]);
    // wordmark 鲸位：简单 pi 图形兜底（主显示走 shellHtml 的 DOM 文字注入）。
    if (raw.whale) brandRewrites.push([raw.whale, PI_MARK_WORDMARK]);
  } catch {
    brandRewrites = [];
  }
  // 字标整段替换（字母+鲸位+HARNESS徽章 → pi 字母图形）。
  try {
    const wordmarkRules = JSON.parse(
      fs.readFileSync(path.join(__dirname, "brand-wordmark.json"), "utf8").replace(/^\uFEFF/, ""),
    );
    if (Array.isArray(wordmarkRules)) brandRewrites.push(...wordmarkRules);
  } catch {
    // 无字标规则文件时跳过
  }
  return brandRewrites;
}

/** 对 shell bundle 应用品牌替换；非 shell 资产原样返回。 */
function rebrandShell(content) {
  const rules = loadBrandRewrites();
  if (!rules.length) return content;
  let out = content;
  for (const [from, to] of rules) out = out.split(from).join(to);
  return out;
}

// ── 品牌文案改写（locale 字典打进各插件 bundle，按包替换） ────────
// key: bundle 路径片段 → 替换规则表（字符串级，避免正则转义坑）。

const BUNDLE_TEXT_REWRITES = {
  "dsh-client-ui-conversation": [
    ['"hero.headline": "探索未至之境"', '"hero.headline": "哈气"'],
    ['"hero.preview": "预览版"', '"hero.preview": "永无止境"'],
  ],
};

/** 对匹配的插件 bundle 应用文案替换（含全局品牌词替换）。 */
function rebrandBundle(bundleId, content) {
  let out = content;
  // 全局品牌词：DeepSeek Harness → pi EAs（locale 文案 + 弹窗正文 + sourcemap 标签一并替换）。
  out = out.split("DeepSeek Harness").join("pi EAs");
  const rules = BUNDLE_TEXT_REWRITES[bundleId];
  if (rules && rules.length) {
    for (const [from, to] of rules) out = out.split(from).join(to);
  }
  return out;
}

// ── HTTP 服务 ──────────────────────────────────────────────────────

const MCCA_DEBUG = process.env.MCCA_DEBUG === "1";
const BODY_LIMIT = 8 * 1024 * 1024; // 与 portal readJsonBody 同级别的防护

/** 解码路径。畸形百分号序列（如 GET /%）decodeURIComponent 会抛 URIError，
 *  这里退回原始未解码路径，避免同步处理器异常导致连接悬挂。 */
function safeDecode(urlPath) {
  try {
    return decodeURIComponent(urlPath);
  } catch {
    return urlPath;
  }
}

const server = http.createServer((req, res) => {
  const pathname = safeDecode(new URL(req.url ?? "/", "http://x").pathname);
  if (MCCA_DEBUG) console.log(`[req] ${req.method} ${pathname}`);

  // 诊断上报端点：浏览器端错误/rejection 收进服务端日志（调试插桩，
  // 默认关闭注入端，端点保留以免已开页面报错）。
  if (req.method === "POST" && pathname === "/mcca/diag") {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > BODY_LIMIT) req.destroy();
    });
    req.on("end", () => {
      if (MCCA_DEBUG) console.log(`[browser-diag] ${body.slice(0, 400)}`);
      sendJson(res, 200, { ok: true });
    });
    return;
  }

  // 一元 RPC：POST /api/<method>（Typert remote 子路径暂不实现，走 not-implemented）
  if (req.method === "POST" && pathname.startsWith("/api/")) {
    const method = pathname.slice("/api/".length).replace(/\/$/, "");
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > BODY_LIMIT) {
        sendJson(res, 413, { type: "server-response", rpcId: "", result: { ok: false, error: "request body too large" } });
        req.destroy();
      }
    });
    req.on("end", () => {
      // dsh wire：响应必须以 {type:'server-response', rpcId, result} 回壳，
      // 客户端按回显的 rpcId 配对在途请求。
      let rpcId = "";
      try {
        const parsed = JSON.parse(body || "{}");
        rpcId = parsed && typeof parsed.rpcId === "string" ? parsed.rpcId : "";
      } catch {
        rpcId = "";
      }
      const wrap = (result) => sendJson(res, 200, { type: "server-response", rpcId, result });
      const unary = API_METHODS[method];
      const remote = REMOTE_METHODS[method];
      const handler = unary ?? remote;
      if (handler === undefined) {
        wrap(notImplemented(method));
        return;
      }
      Promise.resolve(handler(body)).then((value) => {
        // 一元方法自带 RpcResponse 包络；Typert remote 的返回值是裸业务值——
        // 统一包 ok()（真宿主形态：{ok:true, value:...}）。
        if (unary !== undefined) {
          wrap(value);
          return;
        }
        if (value && typeof value === "object" && "ok" in value) {
          wrap(value);
          return;
        }
        wrap(ok(value));
      }, (error) => {
        wrap(rpcError("internal", error instanceof Error ? error.message : String(error)));
      });
    });
    return;
  }

  // 会话删除（归档页删除按钮，与 dsh 侧 packages/session-delete 同路径同语义）：
  // POST /mcca/sessions/delete {sessionId} → 桥接删除 + 三帧客户端收敛。
  if (pathname === "/mcca/sessions/delete") {
    if (req.method !== "POST") {
      res.writeHead(405);
      res.end();
      return;
    }
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > 4096) { req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on("end", () => {
      let body = {};
      try { body = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { /* 视为空体 */ }
      Promise.resolve(bridge.sessionDelete(body)).then((value) => {
        if (value && value.ok === false) {
          // 与 dsh 侧 packages/session-delete 的状态码语义对齐：
          // 找不到=404、运行中=409、参数缺失=400、其余=500。
          const code = value.error && value.error.code;
          const status =
            code === "session-not-found" ? 404
            : code === "session-running" ? 409
            : code === "delete-failed" ? 500
            : 400;
          sendJson(res, status, value);
          return;
        }
        send(res, 200, "application/json; charset=utf-8", JSON.stringify({ ok: true, ...value }));
      }, (error) => {
        send(res, 500, "application/json; charset=utf-8", JSON.stringify({
          ok: false,
          error: { code: "delete-failed", message: error instanceof Error ? error.message : String(error) },
        }));
      });
    });
    req.on("error", () => {});
    return;
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    send(res, 405, "text/plain; charset=utf-8", "Method Not Allowed");
    return;
  }

  // shell
  if (pathname === "/" || pathname === "/index.html") {
    send(res, 200, "text/html; charset=utf-8", shellHtml());
    return;
  }

  // pi 品牌 favicon（替换 DeepSeek 的）
  if (pathname === "/favicon.svg") {
    send(res, 200, "image/svg+xml", piFavicon());
    return;
  }

  // client-hmr 的事件流端点（真宿主为 SSE 长连接；无 HMR 帧可发时保持挂起即可）。
  if (pathname === "/plugins/events") {
    res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-store" });
    // 保持连接打开，不主动发送任何帧（3458 无宿主侧 HMR 推送）。
    return;
  }

  // 客户端插件 bundle：/plugins/<id>/client.js（命中文案改写表的包做替换）
  const pluginMatch = pathname.match(/^\/plugins\/(.+)\/client\.js$/);
  if (pluginMatch) {
    // pathname 已在上游解码，这里不能二次 decodeURIComponent（id 含合法
    // % 时会双重解码成错误字符甚至抛 URIError）。
    const id = pluginMatch[1];
    const file = resolveClientBundle(id);
    if (!file || !fs.existsSync(file)) {
      send(res, 404, "text/plain; charset=utf-8", `no client bundle for ${id}`);
      return;
    }
    const bundleId = id.split("/").pop() || "";
    const raw = fs.readFileSync(file, "utf8");
    send(res, 200, "text/javascript; charset=utf-8", rebrandBundle(bundleId, raw));
    return;
  }

  // dist 静态
  const target = path.normalize(path.join(DIST, pathname));
  if (target.startsWith(DIST + path.sep) && fs.existsSync(target) && fs.statSync(target).isFile()) {
    const body = fs.readFileSync(target);
    const isShell = /^\/assets\/index-[^/]+\.js$/.test(pathname);
    if (isShell) {
      send(res, 200, MIME[".js"], rebrandShell(body.toString("utf8")));
      return;
    }
    send(res, 200, MIME[path.extname(target).toLowerCase()] ?? "application/octet-stream", body);
    return;
  }

  send(res, 404, "text/plain; charset=utf-8", "Not Found");
});

// ── WS：events.mux / events.host（骨架：接受并保持） ────────────────

const muxWss = new WebSocketServer({ noServer: true });
const hostWss = new WebSocketServer({ noServer: true });
// mux 帧广播到所有已连接的 events.mux 客户端（wire 形态同 dsh downlink）。
bridge.onMuxFrame = (frame) => {
  const wire = JSON.stringify({
    type: "server-request",
    rpcId: `mux-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    method: frame.type,
    payload: frame,
  });
  for (const client of muxWss.clients) {
    if (client.readyState === 1) client.send(wire);
  }
};
// host 帧广播（events.host 客户端）：host/session-added、host/workspace-changed
// 等 registry 帧——客户端的工作区分组、会话摘要都靠它们热更新，不发帧
// 新会话/分支就会一直落在“未分组”。
bridge.onHostFrame = (frame) => {
  const wire = JSON.stringify({
    type: "server-request",
    rpcId: `host-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    method: frame.type,
    payload: frame,
  });
  for (const client of hostWss.clients) {
    if (client.readyState === 1) client.send(wire);
  }
};
for (const wss of [muxWss, hostWss]) {
  wss.on("connection", (ws) => {
    // 骨架阶段不发帧；入站帧（订阅/取消）安全忽略。
    ws.on("message", () => {});
    ws.on("error", () => {});
  });
}

server.on("upgrade", (req, socket, head) => {
  const pathname = new URL(req.url ?? "/", "http://x").pathname;
  if (pathname === "/api/events.mux") { muxWss.handleUpgrade(req, socket, head, (ws) => muxWss.emit("connection", ws, req)); return; }
  if (pathname === "/api/events.host") { hostWss.handleUpgrade(req, socket, head, (ws) => hostWss.emit("connection", ws, req)); return; }
  socket.destroy();
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`pi-dsh-web → http://localhost:${PORT}`);
  console.log(`  shell : ${DIST}`);
  console.log(`  boot  : ${BOOT.entries.length} vendor client entries (rev ${BOOT.rev}) + mcca 现算 ${mccaBootEntries().length}（每次响应重算，插件增删改免重启）`);
  // 进程预热：后台建一个丢弃会话，把 SDK 导入、共享插件库装载、
  // MCP 服务器握手全部提前完成（冷启动成本从用户首次点击移到服务启动期）。
  // 用户的会话走共享缓存，暖启动 ~1.4s。
  const t0 = Date.now();
  bridge
    .createSession({}, { warmup: true })
    .then(() => {
      console.log(`[perf] warmup complete in ${Date.now() - t0}ms (session discarded, shared caches hot)`);
    })
    .catch((error) => {
      console.error("[warmup] failed (first real session will pay the cold cost):", error instanceof Error ? error.message : String(error));
    });
});
