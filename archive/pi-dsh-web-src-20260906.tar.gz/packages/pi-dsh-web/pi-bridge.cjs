"use strict";

/**
 * @mcca/pi-dsh-web — pi 会话桥（阶段③④）。
 *
 * 把 pi 的 SessionManager/ModelRuntime/createAgentSession 适配到 dsh 的
 * Web 会话协议面：
 *   - 会话生命周期：create/list/history/models/prompt/cancel/rename/selectModel
 *   - 事件翻译：pi 的扩展事件流 → dsh 的 SessionEvent（turn/start、
 *     user/message、assistant/chunk、turn/end），经 events.mux 推送
 *   - 模型目录：pi 的 runtime 注册表 → llm.providers/llm.models
 *   - 设置：settings.describe/mutate（ui-onboarding 弹窗确认位 +
 *     llm-pi-ai 命名空间镜像 pi 的 models.json，UI 可创建/删除服务商；
 *     set/unset 两式路径操作都接，内置目录路由只写覆盖不遮蔽目录）
 *   - 凭据：credentials.describe/set/unset（页面密钥经引用写通 models.json
 *     条目的 inline apiKey；环境变量是只读层，镜像 dsh 的可写性语义）
 *   - 模型发现：llm.discoverModels（注册表目录直答 → OpenAI 兼容 /models
 *     探测，返回 {models:[{id,name?,contextWindow?,maxTokens?}]}）
 *   - 预设上下文：presetContext.get/set/select（预设=命名规则分组，落盘在
 *     pi 全局 agent 目录，所有工作区共用；会话级多选勾选经 before_agent_start
 *     每条消息注入，mtime 缓存，改动即时生效）+ mcca-preset-context 扩展
 *   - 斜杠命令：commands/execute → pi 原生能力映射
 *
 * 凭据/模型目录默认 pi 全局 agent 目录；会话落盘在工作区
 * config/.pi-agent/sessions（与历史 pi-web 同一落点，旧会话直接可续聊）。
 */

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { PresetContextStore, createPresetContextExtension, normalizePresetInput, contextFileCandidates } = require("./preset-context.cjs");

const ROOT = path.resolve(__dirname, "..", ".."); // D:\dshpi
// 凭据/模型目录：默认 pi 全局 agent 目录（pi CLI 的 auth/models 落点），
// 可用 MCCA_AGENT_DIR 覆盖。
const AGENT_DIR = process.env.MCCA_AGENT_DIR || path.join(process.env.USERPROFILE || "", ".pi", "agent");
// 会话目录：始终留在工作区。
const SESSION_DIR = process.env.MCCA_PI_SESSIONS || path.join(ROOT, "config", ".pi-agent", "sessions");

const loadSdk = () => import("@earendil-works/pi-coding-agent");

class PiBridge {
  /** dsh 内测弹窗的已确认版本（与 ui-settings-models 的 WELCOME_NOTICE_VERSION 对齐）。 */
  static WELCOME_ACK = "2026-08-13.1";

  constructor() {
    this.sdk = null;
    this.runtimePromise = null;
    /** @type {Map<string, { session, unsubscribe, seq, turn, streaming }>} sessionId → 会话态 */
    this.sessions = new Map();
    /** 冷会话索引：sessionId → 磁盘会话文件路径（session.list 时刷新）。 */
    this.sessionPaths = new Map();
    /** mux 广播器：由 server.cjs 注入（frame => void） */
    this.onMuxFrame = null;
    // 预设上下文存储：全部会话共享一个实例（mtime 缓存 + 设置写穿透失效）。
    // 配置落盘在 pi 全局 agent 目录（全局可用，不绑定本仓库工作区）；
    // 工作区旧版设置文件只作首次读取的迁移回退。
    this.presetStore = new PresetContextStore({
      settingsPath: this.globalPresetSettingsFile(),
      legacyPath: this.settingsFile(),
      log: (message) => console.log(`[pi-bridge] ${message}`),
    });
  }

  async sdkReady() {
    if (!this.sdk) this.sdk = await loadSdk();
    return this.sdk;
  }

  async runtime() {
    // models.json 变化时自动重建 runtime（运行中新增/修改模型立即可见，免重启）。
    const modelsPath = path.join(AGENT_DIR, "models.json");
    let mtimeMs = 0;
    try { mtimeMs = fs.statSync(modelsPath).mtimeMs; } catch { /* 无文件按 0 计 */ }
    if (this.runtimePromise && this._runtimeModelsMtime === mtimeMs) return this.runtimePromise;
    this._runtimeModelsMtime = mtimeMs;
    this.runtimePromise = (async () => {
        const sdk = await this.sdkReady();
        const runtime = await sdk.ModelRuntime.create({
          authPath: path.join(AGENT_DIR, "auth.json"),
          modelsPath: path.join(AGENT_DIR, "models.json"), // 自定义 provider 声明（models-store.json 只是缓存）
          allowModelNetwork: false,
        });
        // 环境密钥注入（同旧 pi-web 的语义）。
        const envKeys = {
          anthropic: process.env.ANTHROPIC_API_KEY,
          openai: process.env.OPENAI_API_KEY,
          google: process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY,
          deepseek: process.env.DEEPSEEK_API_KEY,
          groq: process.env.GROQ_API_KEY,
          xai: process.env.XAI_API_KEY,
          mistral: process.env.MISTRAL_API_KEY,
          cerebras: process.env.CEREBRAS_API_KEY,
        };
        for (const [provider, key] of Object.entries(envKeys)) {
          if (key) await runtime.setRuntimeApiKey(provider, key);
        }
        return runtime;
      })();
    this.runtimePromise.catch(() => { this.runtimePromise = null; });
    return this.runtimePromise;
  }

  /**
   * pi 内置目录的服务商行（SDK 自带，不含 models.json 声明）。用一份
   * modelsPath 指向不存在文件的探测 runtime 换取纯目录（进程内缓存一次）：
   * 「declared」（仅因配置而存在的路由）、目录顺序和目录行显示名都靠它。
   */
  nativeCatalog() {
    if (!this._nativeCatalogPromise) {
      this._nativeCatalogPromise = (async () => {
        const sdk = await this.sdkReady();
        const runtime = await sdk.ModelRuntime.create({
          modelsPath: path.join(AGENT_DIR, "models.json.native-catalog-probe-absent"),
          allowModelNetwork: false,
        });
        return (runtime.getProviders() || []).map((p) => ({ id: p.id, name: p.name || p.id }));
      })();
      this._nativeCatalogPromise.catch(() => { this._nativeCatalogPromise = null; });
    }
    return this._nativeCatalogPromise;
  }

  /** 内置目录 id 集合（nativeCatalog 的派生）。 */
  async nativeCatalogIds() {
    return new Set((await this.nativeCatalog()).map((p) => p.id));
  }

  /** 当前 models.json 的 mtime（runtime 与会话新鲜度共用的时间戳）。 */
  currentModelsMtime() {
    try {
      return fs.statSync(path.join(AGENT_DIR, "models.json")).mtimeMs;
    } catch {
      return 0;
    }
  }

  /**
   * 把会话持有的 runtime 换成最新的。AgentSession 在构造时固定 modelRuntime，
   * 此后 models.json 新增/修改的服务商它看不到——setModel 的 checkAuth 和
   * prompt 的 getAuth 都走这个旧实例，会报「No API key for ...」。所有
   * per-session 方法都经 ensureSession，这里按 mtime 检测一次并换新
   * （SDK 未提供公开换口，属性赋值对 0.84.x 的 AgentSession 有效）。
   */
  async refreshSessionRuntime(state) {
    const mtime = this.currentModelsMtime();
    if (state.modelsMtime === mtime) return;
    state.modelsMtime = mtime;
    const fresh = await this.runtime().catch(() => null);
    const session = state.session;
    if (!fresh || !session || session._modelRuntime === fresh) return;
    try {
      session._modelRuntime = fresh;
      console.log("[mcca.pi] session runtime refreshed (models.json changed since session built)");
    } catch (error) {
      console.warn("[mcca.pi] session runtime swap failed:", error instanceof Error ? error.message : String(error));
    }
  }

  // ── 桥自身的通用设置存储（dsh-web 专属，区别于 pi models.json） ────

  settingsFile() {
    // MCCA_BRIDGE_SETTINGS 供测试/多实例隔离（默认落工作区 config/.pi-agent）。
    return process.env.MCCA_BRIDGE_SETTINGS
      || path.join(ROOT, "config", ".pi-agent", "dsh-web-settings.json");
  }

  /**
   * 预设上下文的全局设置文件：pi 全局 agent 目录（凭据/模型同款落点），
   * 跨工作区共用——预设不绑定任何固定仓库目录。
   */
  globalPresetSettingsFile() {
    return path.join(AGENT_DIR, "dsh-web-settings.json");
  }

  readSettings() {
    try {
      return JSON.parse(fs.readFileSync(this.settingsFile(), "utf8").replace(/^\uFEFF/, ""));
    } catch {
      return {};
    }
  }

  writeSettings(data) {
    fs.mkdirSync(path.dirname(this.settingsFile()), { recursive: true });
    fs.writeFileSync(this.settingsFile(), `${JSON.stringify(data, null, 2)}\n`, "utf8");
  }

  // ── 设置面：settings.describe / settings.mutate ──────────────────

  /** 单个 namespace 的视图（含 schemastery envelope 形态的 schema）。 */
  namespaceView(ns, value, schema, user) {
    return {
      ns,
      schema: schema ?? { type: "object", dict: {}, meta: { default: {} } },
      value,
      user: user ?? value,
      applies: "live",
      secrets: [],
      revision: 0,
    };
  }

  /** 页面派生凭据引用（与 piToDshProvider 的镜像口径一致）。 */
  credentialRefFor(name) {
    return `${String(name).toUpperCase().replace(/[^A-Z0-9]/g, "_")}_API_KEY`;
  }

  /** pi models.json provider 条目 → dsh llm-pi-ai 条目（baseUrl→baseURL；key 不出网）。 */
  piToDshProvider(name, p) {
    const thresholds = this.readCompactionThresholds();
    const entry = p || {};
    // 真实密钥不回传到浏览器；configured 判定只看条目存在。
    const apiKeyEnv = entry.apiKeyEnv
      || (typeof entry.apiKey === "string" && entry.apiKey ? this.credentialRefFor(name) : undefined);
    return {
      displayName: this.readDisplayNames()[name] || name,
      // 不给 api 合成默认值：内置目录路由的协议由目录决定，合成值会经
      // 单字段补丁写回条目、把路由钉死在 openai-completions 上。
      api: entry.api || "",
      baseURL: entry.baseUrl || "",
      ...(apiKeyEnv ? { apiKeyEnv } : {}),
      models: (entry.models || []).map((m) => ({
        id: m.id,
        name: m.name || m.id,
        reasoning: Boolean(m.reasoning),
        input: m.input || ["text"],
        contextWindow: m.contextWindow,
        maxTokens: m.maxTokens,
        // 压缩阈值存在本桥自己的存储里（pi models.json 的 schema 不认识它），
        // 镜像回显让设置卡片显示当前值。
        ...(thresholds[`${name}/${m.id}`] !== undefined
          ? { compactionThreshold: thresholds[`${name}/${m.id}`] }
          : {}),
      })),
    };
  }

  /** dsh llm-pi-ai 条目 → pi models.json provider（写回路径；key 缺省时保留原值）。 */
  dshToPiProvider(name, d, existing, { native = false } = {}) {
    // 压缩阈值先落本桥存储，再从写入 models.json 的条目里剥掉——
    // pi 的模型 schema 不认识这个字段，塞进去有被 schema 校验/清洗丢弃的风险。
    if (Array.isArray(d.models)) this.syncCompactionThresholds(name, d.models);
    // displayName 是界面概念（pi 的 models.json 没有 display 字段），落本桥侧存；
    // apiKeyEnv 是凭据引用（密钥本体走 credentials 面），两边都不进条目。
    this.syncDisplayName(name, d.displayName);
    const entry = { ...(existing || {}) };
    delete entry.displayName;
    delete entry.apiKeyEnv;
    // 兼容旧直填路径（profile 内联 apiKey，如烟测脚本）；页面本身走 credentials.set。
    if (typeof d.apiKey === "string" && d.apiKey && d.apiKey !== "***") entry.apiKey = d.apiKey;
    const draftModels = Array.isArray(d.models)
      ? d.models
        .filter((m) => m && typeof m.id === "string" && m.id.trim())
        .map((m) => {
          // compactionThreshold / reasoningEfforts 是 dsh 面的概念，pi 条目不收；
          // id/name 去首尾空白——带空格的 id 会在选择器与请求里原样携带。
          const { compactionThreshold, reasoningEfforts, ...rest } = m;
          const id = m.id.trim();
          const name = (m.name || id).trim();
          return {
            ...rest,
            id,
            name,
            reasoning: Boolean(m.reasoning),
            input: m.input || ["text"],
            ...(m.contextWindow ? { contextWindow: m.contextWindow } : {}),
            ...(m.maxTokens ? { maxTokens: m.maxTokens } : {}),
          };
        })
      : null;
    if (native) {
      // 内置目录路由：只写用户给出的覆盖，缺省字段继承目录。models 缺席保留
      // 目录模型——绝不能用「api + 空 models」的空壳条目把内置服务商遮蔽坏。
      if (d.api) entry.api = d.api;
      if (d.baseURL) entry.baseUrl = d.baseURL;
      if (draftModels && draftModels.length) entry.models = draftModels;
      else delete entry.models;
    } else {
      entry.api = d.api || (existing && existing.api) || "openai-completions";
      entry.baseUrl = d.baseURL || (existing && existing.baseUrl) || "";
      entry.models = draftModels && draftModels.length
        ? draftModels
        : (existing && existing.models) || [];
    }
    return entry;
  }

  // ── displayName 侧存（pi 的 models.json 没有 display 字段） ────────

  readDisplayNames() {
    const stored = this.readSettings();
    const ns = stored["display-names"];
    return ns && typeof ns === "object" && !Array.isArray(ns) ? { ...ns } : {};
  }

  writeDisplayNames(map) {
    const stored = this.readSettings();
    stored["display-names"] = map;
    this.writeSettings(stored);
  }

  /** 同步一次 provider 编辑产生的显示名：非空且异于路由 id 则记录，否则移除。 */
  syncDisplayName(name, displayName) {
    const map = this.readDisplayNames();
    if (typeof displayName === "string" && displayName && displayName !== name) {
      if (map[name] !== displayName) {
        map[name] = displayName;
        this.writeDisplayNames(map);
      }
    } else if (name in map) {
      delete map[name];
      this.writeDisplayNames(map);
    }
  }

  // ── 压缩阈值存储（pi 面的“压缩阈值”设置） ─────────────────────────
  //
  // pi 的自动压缩在 contextTokens > contextWindow − reserveTokens 时触发；
  // 本桥把设置里的百分比换算成 reserveTokens（= contextWindow × (1 − pct/100)）
  // 经包装的 SettingsManager 注入会话，对当前模型即时生效。

  /** 阈值存储：本桥设置的 compaction-thresholds 命名空间（"provider/model" → 百分比）。 */
  readCompactionThresholds() {
    const stored = this.readSettings();
    const ns = stored["compaction-thresholds"];
    return ns && typeof ns === "object" && !Array.isArray(ns) ? { ...ns } : {};
  }

  writeCompactionThresholds(map) {
    const stored = this.readSettings();
    stored["compaction-thresholds"] = map;
    this.writeSettings(stored);
  }

  /** 同步一次 provider 编辑产生的阈值：数值有效则落库，字段缺席则移除。 */
  syncCompactionThresholds(providerName, models) {
    const thresholds = this.readCompactionThresholds();
    let changed = false;
    for (const m of models) {
      if (!m || typeof m.id !== "string" || !m.id) continue;
      const key = `${providerName}/${m.id}`;
      const pct = m.compactionThreshold;
      if (typeof pct === "number" && Number.isInteger(pct) && pct >= 1 && pct <= 100) {
        if (thresholds[key] !== pct) {
          thresholds[key] = pct;
          changed = true;
        }
      } else if (key in thresholds) {
        delete thresholds[key];
        changed = true;
      }
    }
    if (changed) this.writeCompactionThresholds(thresholds);
  }

  /** 当前模型配置的压缩阈值百分比；未配置或非法返回 undefined（用 pi 默认）。 */
  thresholdPercentFor(providerName, modelId) {
    const pct = this.readCompactionThresholds()[`${providerName}/${modelId}`];
    return typeof pct === "number" && Number.isInteger(pct) && pct >= 1 && pct <= 100 ? pct : undefined;
  }

  /** pi 全局 models.json（自定义 provider 的权威落点）。 */
  piModelsFile() {
    return path.join(AGENT_DIR, "models.json");
  }

  readPiModels() {
    try {
      const parsed = JSON.parse(fs.readFileSync(this.piModelsFile(), "utf8").replace(/^\uFEFF/, ""));
      if (parsed && typeof parsed === "object" && typeof parsed.providers === "object") return parsed;
    } catch {
      // 读失败按空目录处理
    }
    return { providers: {} };
  }

  writePiModels(data) {
    fs.writeFileSync(this.piModelsFile(), `${JSON.stringify(data, null, 2)}\n`, "utf8");
  }

  /**
   * 向服务商拉取模型清单（OpenAI 兼容的 `GET {baseUrl}/models`）。
   *
   * 添加服务商最费时的动作是逐个手填模型（id / name / contextWindow /
   * maxTokens / cost / compat…），而这些 id 本来就躺在服务商的 /models 里。
   * 所以整条 provider 保存时若模型清单为空，这里自动填成 `{id, name}`：
   * contextWindow 等字段 pi 的 schema 允许缺席（现有配置里就有只写 id 的条目），
   * 需要精调的用户之后在模型编辑里补即可。
   *
   * 失败不静默：错误经原生通知抛出，否则用户只会看到“保存成功但没有模型”。
   *
   * @param {string} baseUrl 服务商端点（可带或不带结尾斜杠）。
   * @param {string} apiKey  访问密钥；空则不带 authorization 头。
   * @returns {Promise<{ models: Array<object>, error: string | null }>}
   */
  async discoverProviderModels(baseUrl, apiKey) {
    const url = `${String(baseUrl).replace(/\/+$/, "")}/models`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const res = await fetch(url, {
        headers: apiKey ? { authorization: `Bearer ${apiKey}` } : {},
        signal: controller.signal,
      });
      if (!res.ok) return { models: [], error: `${url} → HTTP ${res.status}` };
      const body = await res.json();
      const rows = Array.isArray(body?.data) ? body.data : Array.isArray(body?.models) ? body.models : [];
      const seen = new Set();
      const models = [];
      for (const row of rows) {
        const id = typeof row === "string" ? row.trim()
          : typeof row?.id === "string" ? row.id.trim()
            : typeof row?.name === "string" ? row.name.trim() : "";
        if (!id || seen.has(id)) continue;
        seen.add(id);
        // 与 dsh 的 readListing 同口径：候选带 name/容量元数据，采纳的行不用再补。
        const rawName = typeof row?.name === "string" ? row.name.trim()
          : typeof row?.display_name === "string" ? row.display_name.trim() : "";
        const name = rawName && rawName !== id ? rawName : undefined;
        const contextWindow = [row?.context_window, row?.context_length].find(
          (v) => typeof v === "number" && Number.isInteger(v) && v > 0,
        );
        const maxTokens = [row?.max_output_tokens, row?.max_tokens].find(
          (v) => typeof v === "number" && Number.isInteger(v) && v > 0,
        );
        models.push({
          id,
          ...(name ? { name } : {}),
          ...(contextWindow ? { contextWindow } : {}),
          ...(maxTokens ? { maxTokens } : {}),
        });
        if (models.length >= 200) break;
      }
      return models.length
        ? { models, error: null }
        : { models: [], error: `${url} 返回了 0 个模型（端点或密钥可能不对）` };
    } catch (error) {
      const message = error?.name === "AbortError" ? `${url} 请求超时（8s）` : `${url} → ${error?.message || error}`;
      return { models: [], error: message };
    } finally {
      clearTimeout(timer);
    }
  }

  // ── 凭据面（credentials.*）：页面密钥写入的唯一通道 ───────────────
  //
  // dsh 的凭据缝把「引用名」和「值」分开：profile 记 apiKeyEnv 引用，值经
  // credentials.set 存进可写层。pi 侧的等价落点是 models.json 条目的 inline
  // apiKey（runtime 按它解析请求密钥），所以 set/unset 直接写通条目；引用
  // 匹配不到任何服务商时落桥自己的孤儿存储，等 profile 落地后 describe 仍可见。

  readCredentialStore() {
    const stored = this.readSettings();
    const ns = stored.credentials;
    return ns && typeof ns === "object" && !Array.isArray(ns) ? { ...ns } : {};
  }

  writeCredentialStore(map) {
    const stored = this.readSettings();
    stored.credentials = map;
    this.writeSettings(stored);
  }

  /** 引用 → 服务商条目（条目 apiKeyEnv 优先，其次按路由 id 的派生引用）。 */
  findProviderByRef(ref) {
    const providers = this.readPiModels().providers || {};
    for (const [name, p] of Object.entries(providers)) {
      if ((p && p.apiKeyEnv) === ref || this.credentialRefFor(name) === ref) return { name, p };
    }
    return null;
  }

  /** credentials.describe：批量回答引用状态（绝不含值）。 */
  async credentialsDescribe(payload) {
    const refs = Array.isArray(payload?.refs) ? payload.refs.map(String).filter(Boolean) : [];
    const orphan = this.readCredentialStore();
    const credentials = {};
    for (const ref of refs) {
      // 环境变量是只读层：镜像 dsh 语义（writable:false，set 会被拒）。
      if (String(process.env[ref] ?? "").trim()) {
        credentials[ref] = { configured: true, source: "env", writable: false };
        continue;
      }
      let configured = typeof orphan[ref] === "string" && orphan[ref].length > 0;
      if (!configured) {
        const matched = this.findProviderByRef(ref);
        configured = Boolean(matched && matched.p && typeof matched.p.apiKey === "string" && matched.p.apiKey);
      }
      credentials[ref] = { configured, ...(configured ? { source: "file" } : {}), writable: true };
    }
    return { credentials };
  }

  /** credentials.set：把密钥写进匹配服务商的 models.json 条目（或孤儿存储）。 */
  async credentialsSet(payload) {
    const ref = String(payload?.ref ?? "");
    const value = typeof payload?.value === "string" ? payload.value : "";
    if (!ref) return { ok: false, error: { code: "bad-request", message: "credentials.set: missing ref", details: { issues: ["missing ref"] } } };
    if (!value) return { ok: false, error: { code: "bad-request", message: "credentials.set: empty value", details: { issues: ["empty value"] } } };
    if (String(process.env[ref] ?? "").trim()) {
      return { ok: false, error: { code: "credential-rejected", message: `${ref} 由环境变量提供（只读层），不能覆盖`, details: { ref } } };
    }
    const matched = this.findProviderByRef(ref);
    if (matched) {
      const piModels = this.readPiModels();
      piModels.providers[matched.name] = { ...matched.p, apiKey: value };
      this.writePiModels(piModels);
      // 让当前 runtime 实例立刻看到新密钥（models.json 变更也会触发下次重建）。
      try {
        const runtime = await this.runtime();
        if (runtime && typeof runtime.setRuntimeApiKey === "function") {
          await runtime.setRuntimeApiKey(matched.name, value);
        }
      } catch (error) {
        console.warn(`[mcca.pi] credentials.set: runtime key refresh failed: ${error instanceof Error ? error.message : error}`);
      }
    } else {
      const store = this.readCredentialStore();
      store[ref] = value;
      this.writeCredentialStore(store);
    }
    return {};
  }

  /** credentials.unset：清除引用（幂等；手写的 !command/$ENV 值不动）。 */
  async credentialsUnset(payload) {
    const ref = String(payload?.ref ?? "");
    if (!ref) return { ok: false, error: { code: "bad-request", message: "credentials.unset: missing ref", details: { issues: ["missing ref"] } } };
    if (String(process.env[ref] ?? "").trim()) {
      return { ok: false, error: { code: "credential-rejected", message: `${ref} 由环境变量提供（只读层），不能清除`, details: { ref } } };
    }
    const store = this.readCredentialStore();
    const orphanValue = store[ref];
    if (ref in store) {
      delete store[ref];
      this.writeCredentialStore(store);
    }
    const matched = this.findProviderByRef(ref);
    if (matched && typeof matched.p.apiKey === "string") {
      // 只清页面写入的明文字面量；`!command` / `$ENV` 这类手写表达式保留。
      const pageManaged = !matched.p.apiKey.startsWith("!") && !matched.p.apiKey.startsWith("$")
        && (orphanValue === undefined || matched.p.apiKey === orphanValue);
      if (pageManaged) {
        const piModels = this.readPiModels();
        const entry = { ...piModels.providers[matched.name] };
        delete entry.apiKey;
        piModels.providers[matched.name] = entry;
        this.writePiModels(piModels);
      }
    }
    return {};
  }

  /** 删除服务商时连带清理桥侧的周边状态（阈值/显示名/孤儿凭据）。 */
  forgetProviderSideState(name) {
    const thresholds = this.readCompactionThresholds();
    const prefix = `${name}/`;
    const orphanKeys = Object.keys(thresholds).filter((k) => k.startsWith(prefix));
    if (orphanKeys.length) {
      for (const k of orphanKeys) delete thresholds[k];
      this.writeCompactionThresholds(thresholds);
    }
    const names = this.readDisplayNames();
    if (name in names) {
      delete names[name];
      this.writeDisplayNames(names);
    }
    const ref = this.credentialRefFor(name);
    const store = this.readCredentialStore();
    if (ref in store) {
      delete store[ref];
      this.writeCredentialStore(store);
    }
  }

  /** dsh 字段名 → pi models.json 字段名（unset 路径用）。 */
  piFieldKey(key) {
    return key === "baseURL" ? "baseUrl" : key;
  }

  /** llm-pi-ai namespace 的最小 schemastery envelope（ProviderEditor 渲染用）。 */
  piAiSchema() {
    // api 必须是 union（成员带 value）：设置页的 protocolChoices 从 schema 读
    // 协议列表，读到空列表时「自定义服务商」入口整个被禁用。成员形态对齐
    // schemastery toJSON 的序列化（const 节点），rehydrateSchema 后 .value 可读。
    return {
      type: "object",
      meta: { default: {} },
      dict: {
        providers: {
          type: "dict",
          meta: { default: {} },
          inner: {
            type: "object",
            meta: { default: {} },
            dict: {
              displayName: { type: "string", meta: {} },
              api: {
                type: "union",
                meta: {},
                list: [
                  { type: "const", meta: { required: true }, value: "openai-completions" },
                  { type: "const", meta: { required: true }, value: "openai-responses" },
                  { type: "const", meta: { required: true }, value: "anthropic-messages" },
                  { type: "const", meta: { required: true }, value: "google-generative-ai" },
                ],
              },
              baseURL: { type: "string", meta: {} },
              apiKey: { type: "string", meta: { role: "secret" } },
              apiKeyEnv: { type: "string", meta: {} },
              models: {
                type: "array",
                meta: { default: [] },
                inner: {
                  type: "object",
                  meta: { default: {} },
                  dict: {
                    id: { type: "string", meta: {} },
                    name: { type: "string", meta: {} },
                    reasoning: { type: "boolean", meta: {} },
                    contextWindow: { type: "number", meta: {} },
                    maxTokens: { type: "number", meta: {} },
                    compactionThreshold: { type: "number", meta: {} },
                  },
                },
              },
            },
          },
        },
      },
    };
  }

  /** settings.describe：ui-onboarding 预置已确认；llm-pi-ai 镜像 pi models.json。 */
  async settingsDescribe() {
    const stored = this.readSettings();
    const namespaces = Object.entries(stored).map(([ns, value]) => this.namespaceView(ns, value));
    if (!stored["ui-onboarding"]) {
      namespaces.push(this.namespaceView("ui-onboarding", { welcomeNoticeVersion: PiBridge.WELCOME_ACK }));
    }
    const piModels = this.readPiModels();
    const mirrored = { providers: {} };
    for (const [name, p] of Object.entries(piModels.providers || {})) {
      mirrored.providers[name] = this.piToDshProvider(name, p);
    }
    namespaces.push(this.namespaceView("llm-pi-ai", mirrored, this.piAiSchema(), mirrored));
    return { writable: true, hasDocument: false, namespaces };
  }

  /** settings.mutate：llm-pi-ai 写回 pi models.json，其余 namespace 落 JSON 文件。 */
  async settingsMutate(payload) {
    const ns = String(payload.ns ?? "");
    if (!ns) return { ok: false, error: { code: "internal", message: "settings.mutate: missing ns" } };
    const ops = Array.isArray(payload.ops) ? payload.ops : [];

    if (ns === "llm-pi-ai") {
      const piModels = this.readPiModels();
      const existing = piModels.providers || {};
      const written = new Set();
      const nativeIds = await this.nativeCatalogIds();
      for (const op of ops) {
        if (!op || typeof op !== "object") continue;
        const segs = Array.isArray(op.path) ? op.path.map(String) : [];
        // 只支持 ['providers', name] 与 ['providers', name, ...字段] 两层形态。
        if (segs[0] !== "providers" || segs.length < 2 || !segs[1]) continue;
        const name = segs[1];
        // 客户端的删除/清空操作是 unset（pathOps 的移除路径），remove 是旧
        // 语义——两者都接受，否则页面上删除服务商是静默空操作。
        if ((op.op === "remove" || op.op === "unset") && segs.length === 2) {
          delete existing[name];
          this.forgetProviderSideState(name);
          continue;
        }
        if (op.op === "unset" && segs.length > 2) {
          // 字段级清除：直接在 pi 条目上删（dsh 字段名 → pi 字段名映射），
          // 不能走镜像补丁——空值回退会变成「清不掉」。
          const entry = existing[name] || {};
          let cursor = entry;
          let walkable = true;
          for (let i = 2; i < segs.length - 1; i += 1) {
            const key = this.piFieldKey(String(segs[i]));
            if (typeof cursor[key] !== "object" || cursor[key] === null) { walkable = false; break; }
            cursor = cursor[key];
          }
          if (walkable) delete cursor[this.piFieldKey(String(segs[segs.length - 1]))];
          if (String(segs[segs.length - 1]) === "displayName") this.syncDisplayName(name, undefined);
          existing[name] = entry;
          continue;
        }
        if (op.op !== "set") continue;
        if (segs.length === 2) {
          // 整条 provider 写入（CustomProviderCard 的提交路径）。
          existing[name] = this.dshToPiProvider(name, op.value ?? {}, existing[name], { native: nativeIds.has(name) });
          written.add(name);
        } else {
          // 单字段补丁：合并进现有条目。
          const current = this.piToDshProvider(name, existing[name] || {});
          let cursor = current;
          for (let i = 2; i < segs.length - 1; i += 1) {
            if (typeof cursor[segs[i]] !== "object" || cursor[segs[i]] === null) cursor[segs[i]] = {};
            cursor = cursor[segs[i]];
          }
          if (segs.length >= 3) cursor[segs[segs.length - 1]] = op.value;
          existing[name] = this.dshToPiProvider(name, current, existing[name], { native: nativeIds.has(name) });
        }
      }
      // 引用先于条目落地（credentials.set 时服务商还不存在）的密钥存进孤儿
      // 存储；条目此刻补齐就合并回条目并清掉孤儿副本，密钥不滞留侧文件。
      const orphanStore = this.readCredentialStore();
      for (const name of written) {
        const provider = existing[name];
        if (!provider || provider.apiKey) continue;
        const ref = provider.apiKeyEnv || this.credentialRefFor(name);
        if (typeof orphanStore[ref] === "string" && orphanStore[ref]) {
          provider.apiKey = orphanStore[ref];
          delete orphanStore[ref];
          this.writeCredentialStore(orphanStore);
        }
      }
      // 新建/整体保存且没填模型 → 自动向服务商拉一次 /models。这一步把
      // “添加服务商”从逐条手填模型变成填端点和密钥就能用。
      for (const name of written) {
        const provider = existing[name];
        if (!provider || !provider.baseUrl) continue;
        if (Array.isArray(provider.models) && provider.models.length) continue;
        const apiKey = provider.apiKey || (provider.apiKeyEnv ? process.env[provider.apiKeyEnv] : "");
        const { models, error } = await this.discoverProviderModels(provider.baseUrl, apiKey);
        if (models.length) {
          provider.models = models;
          console.log(`[mcca.pi] provider "${name}": discovered ${models.length} models`);
        } else {
          console.warn(`[mcca.pi] provider "${name}": model discovery failed: ${error}`);
          this.notifyPortal(`pi 服务商「${name}」模型拉取失败`, String(error || "未知原因"));
        }
      }
      piModels.providers = existing;
      this.writePiModels(piModels);
      const mirrored = { providers: {} };
      for (const [name, p] of Object.entries(existing)) {
        mirrored.providers[name] = this.piToDshProvider(name, p);
      }
      return this.namespaceView("llm-pi-ai", mirrored, this.piAiSchema(), mirrored);
    }

    const stored = this.readSettings();
    const value = typeof stored[ns] === "object" && stored[ns] !== null ? stored[ns] : {};
    for (const op of ops) {
      if (!op || typeof op !== "object") continue;
      if (op.op === "set") {
        let cursor = value;
        const segs = Array.isArray(op.path) ? op.path : [];
        for (let i = 0; i < segs.length - 1; i += 1) {
          const seg = String(segs[i]);
          if (typeof cursor[seg] !== "object" || cursor[seg] === null) cursor[seg] = {};
          cursor = cursor[seg];
        }
        if (segs.length) cursor[String(segs[segs.length - 1])] = op.value;
      } else if (op.op === "remove" || op.op === "unset") {
        const segs = Array.isArray(op.path) ? op.path : [];
        let cursor = value;
        for (let i = 0; i < segs.length - 1 && cursor; i += 1) {
          cursor = cursor[String(segs[i])];
        }
        if (cursor && segs.length) delete cursor[String(segs[segs.length - 1])];
      }
    }
    stored[ns] = value;
    this.writeSettings(stored);
    return this.namespaceView(ns, value);
  }

  // ── 目录面：插件 / 技能 / MCP（对齐 dsh 宿主的 inventory 远程） ────
  //
  // dsh 前端的三块管理面板（设置里的插件清单、侧栏的技能页与 MCP 页）全部
  // 经 Typert Remote 读取宿主目录。pi 桥在此把共享库的三份事实源投影成与
  // 真宿主一致的 wire 形态：
  //   插件 → plugins/ 目录 + config/plugins.json（pi 一侧启用态）
  //   技能 → skills/ 目录的 SKILL.md frontmatter + 本桥自己的禁用名单
  //   MCP  → config/mcp.json + pi-mcp 共享连接的实时工具表

  /** 共享插件库目录与启用配置（与 pi-adapter 同源）。 */
  pluginsDir() {
    return path.join(ROOT, "plugins");
  }

  pluginsConfigPath() {
    return path.join(ROOT, "config", "plugins.json");
  }

  /** 共享技能库目录（与 DefaultResourceLoader.additionalSkillPaths 同源）。 */
  skillsDir() {
    return path.join(ROOT, "skills");
  }

  /** 共享 MCP 注册表（与 readMcpServers 同源）。 */
  mcpConfigPath() {
    return path.join(ROOT, "config", "mcp.json");
  }

  /**
   * pluginInventory.list：共享插件库 → PluginInventorySnapshot。
   *
   * 真宿主的形态字段逐一对齐：entryId/moduleName/enabled/fiberPhase/source/
   * description/version。pi 侧没有 Cordis Loader，fiberPhase 如实反映启用
   * 与否（active / null）；source 全部是 library（共享库由用户维护，非随
   * 安装发布的 native 插件）；moduleName 用插件的 file:// 入口（与真宿主
   * "Loader 行的模块名"语义一致）。
   */
  async pluginInventoryList() {
    const { discoverPlugins, readEnableConfig } = await import("@mcca/plugin-host");
    const config = readEnableConfig(this.pluginsConfigPath());
    const entries = discoverPlugins(this.pluginsDir()).map((plugin) => {
      const manifest = plugin.manifest || {};
      const enabled = config.pi?.[manifest.name] ?? true;
      return {
        entryId: manifest.name,
        moduleName: `file://${plugin.entryPath.replaceAll("\\", "/")}`,
        enabled,
        fiberPhase: enabled ? "active" : null,
        source: "library",
        description: typeof manifest.description === "string" ? manifest.description : null,
        version: typeof manifest.version === "string" ? manifest.version : null,
      };
    });
    return { entries };
  }

  /**
   * pluginInventory.setEnabled：写回 config/plugins.json 的 pi 段。
   *
   * 真宿主持久化到 profile 的用户 patch 层并热应用到 Loader；pi 桥的等价物
   * 是共享库的启用配置（pi 的 extensionFactories 按会话装配，新会话即按新
   * 配置装载）。返回刷新后的快照。
   */
  async pluginInventorySetEnabled(payload) {
    const entryId = String(payload.entryId ?? "");
    const enabled = Boolean(payload.enabled);
    const { discoverPlugins, readEnableConfig } = await import("@mcca/plugin-host");
    if (!discoverPlugins(this.pluginsDir()).some((p) => p.manifest.name === entryId)) {
      return { ok: false, error: { code: "internal", message: `pluginInventory.setEnabled: unknown plugin ${entryId}` } };
    }
    const configPath = this.pluginsConfigPath();
    const config = readEnableConfig(configPath);
    const next = { ...config, pi: { ...(config.pi ?? {}), [entryId]: enabled } };
    fs.mkdirSync(path.dirname(configPath), { recursive: true });
    fs.writeFileSync(configPath, `${JSON.stringify(next, null, 2)}\n`, "utf8");
    return this.pluginInventoryList();
  }

  /** 解析 SKILL.md 的 YAML frontmatter（name/description 等平铺字段）。 */
  parseSkillFrontmatter(text) {
    const match = /^---\r?\n([\s\S]*?)\r?\n---/.exec(text);
    if (!match) return null;
    const fields = {};
    for (const line of match[1].split(/\r?\n/)) {
      const field = /^([A-Za-z0-9_-]+):\s*(.*)$/.exec(line);
      if (!field) continue;
      const raw = field[2].trim();
      fields[field[1]] = raw.length >= 2 && raw.startsWith('"') && raw.endsWith('"')
        ? raw.slice(1, -1).replace(/\\"/g, '"')
        : raw;
    }
    return fields;
  }

  /** 技能启用态的持久落点：本桥设置的 skill-enablement 命名空间。 */
  readSkillDisabled() {
    const stored = this.readSettings();
    const ns = stored["skill-enablement"];
    return Array.isArray(ns?.disabled) ? ns.disabled.map(String) : [];
  }

  writeSkillDisabled(disabled) {
    const stored = this.readSettings();
    stored["skill-enablement"] = { disabled: [...disabled] };
    this.writeSettings(stored);
  }

  /**
   * 扫描共享技能库 → 供 UI 与 skill.list 共用的条目集。
   *
   * 每个含 SKILL.md 的目录是一项；frontmatter 决定 name/description/
   * when_to_use 与 disable-model-invocation（对齐 dsh-skill 的约定）。
   * 读失败或无 frontmatter 的目录跳过（对齐 dsh 技能装载的失败语义）。
   */
  scanSharedSkills() {
    const dir = this.skillsDir();
    if (!fs.existsSync(dir)) return [];
    const out = [];
    for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      if (!entry.isDirectory()) continue;
      const file = path.join(dir, entry.name, "SKILL.md");
      if (!fs.existsSync(file)) continue;
      let text;
      try {
        text = fs.readFileSync(file, "utf8").replace(/^\uFEFF/, "");
      } catch {
        continue;
      }
      const front = this.parseSkillFrontmatter(text);
      if (!front || !front.name) continue;
      out.push({
        name: front.name,
        description: front.description || "",
        ...(front.when_to_use || front.whenToUse ? { whenToUse: front.when_to_use || front.whenToUse } : {}),
        provider: "mcca-filesystem",
        source: path.join(dir, entry.name),
        invocation: {
          modelInvocable: String(front["disable-model-invocation"] ?? "").trim() !== "true",
          userInvocable: true,
        },
        content: text,
      });
    }
    return out;
  }

  /** skillInventory.list：共享技能库 → SkillInventorySnapshot（禁用名单折入）。 */
  skillInventoryList() {
    const disabled = new Set(this.readSkillDisabled());
    const entries = this.scanSharedSkills().map((skill) => {
      const { content, ...rest } = skill;
      return { ...rest, enabled: !disabled.has(skill.name) };
    });
    return { entries };
  }

  /**
   * skillInventory.get：单个技能的完整正文（详情展开用）。
   * 未知名称返回 undefined（与真宿主一致，前端按 undefined 处理）。
   */
  skillInventoryGet(payload) {
    const name = String(payload.name ?? "");
    const disabled = new Set(this.readSkillDisabled());
    const skill = this.scanSharedSkills().find((s) => s.name === name);
    if (!skill) return undefined;
    return { ...skill, enabled: !disabled.has(name) };
  }

  /**
   * skillInventory.setEnabled：写回禁用名单并返回刷新后的快照。
   * 与真宿主同语义：禁用集整体替换，schema 默认值不会悄悄复活被禁技能。
   */
  skillInventorySetEnabled(payload) {
    const name = String(payload.name ?? "");
    const enabled = Boolean(payload.enabled);
    const disabled = new Set(this.readSkillDisabled());
    if (enabled) disabled.delete(name);
    else disabled.add(name);
    this.writeSkillDisabled([...disabled]);
    return this.skillInventoryList();
  }

  /** MCP 启用态：与技能同一份桥设置（命名空间 mcp-enablement）。 */
  readMcpDisabled() {
    const stored = this.readSettings();
    const ns = stored["mcp-enablement"];
    return Array.isArray(ns?.disabled) ? ns.disabled.map(String) : [];
  }

  /**
   * mcpInventory.list：共享 MCP 注册表 + pi-mcp 共享连接的实时工具表。
   *
   * 真宿主按 `mcp__<serverName>__` 前缀从工具注册表聚合每个服务器的工具；
   * pi 桥的等价物是 pi-mcp 的进程级共享客户端（与 pi 会话实际调用走同一
   * 连接）。status 推导对齐真宿主：enabled 且有工具 = active，enabled 无
   * 工具 = error，disabled = disabled。
   */
  async mcpInventoryList() {
    const { readMcpServers, peekSharedMcpTools } = await import("@mcca/pi-mcp");
    const servers = readMcpServers(this.mcpConfigPath());
    const disabledNames = this.readMcpDisabled();
    const rows = await Promise.all(
      servers.map(async (server) => {
        let tools = [];
        let connected = false;
        try {
          const peeked = await peekSharedMcpTools(server);
          tools = peeked.tools;
          connected = peeked.connected;
        } catch {
          // 连接失败（服务器不可启动等）按 error 状态显示，不阻塞整表
        }
        const enabled = !disabledNames.includes(server.serverName);
        return {
          name: server.serverName,
          entryId: `mcp-${server.serverName}`,
          transport: String(server.transport ?? "stdio"),
          enabled,
          status: !enabled ? "disabled" : connected && tools.length > 0 ? "active" : "error",
          tools: tools.map((tool) => ({
            name: `mcp__${server.serverName}__${tool.name}`,
            description: tool.description || "",
          })),
        };
      }),
    );
    return { servers: rows };
  }

  /**
   * mcpInventory.setEnabled：持久化服务器启用态并返回刷新后的快照。
   *
   * pi 会话按启用态过滤注册表装载 MCP 工具（buildSession 读到新名单后
   * 新会话生效）；与真宿主"持久化 + 热应用"一致，落点是本桥设置。
   */
  async mcpInventorySetEnabled(payload) {
    const name = String(payload.name ?? "");
    const enabled = Boolean(payload.enabled);
    const { readMcpServers } = await import("@mcca/pi-mcp");
    if (!readMcpServers(this.mcpConfigPath()).some((s) => s.serverName === name)) {
      return { ok: false, error: { code: "internal", message: `mcpInventory.setEnabled: unknown MCP server ${name}` } };
    }
    const disabled = new Set(this.readMcpDisabled());
    if (enabled) disabled.delete(name);
    else disabled.add(name);
    const stored = this.readSettings();
    stored["mcp-enablement"] = { disabled: [...disabled] };
    this.writeSettings(stored);
    return this.mcpInventoryList();
  }

  /** skill.list（composer 的 / 菜单）：共享技能目录 → SkillEntry 投影。 */
  async skillList(payload) {
    const id = String(payload.sessionId ?? "");
    // 真宿主要求会话已附着（cold 会话由 header 的 cwd 解析）；pi 桥的目录
    // 是全工作区共享的单一库，attached 与否不影响内容，但会话必须存在。
    const state = this.sessions.get(id);
    if (!state) {
      return { ok: false, error: { code: "session-not-found", message: `session "${id}" not found (not attached)`, details: { sessionId: id } } };
    }
    const disabled = new Set(this.readSkillDisabled());
    const skills = this.scanSharedSkills()
      .filter((s) => s.invocation.userInvocable)
      .map((s) => ({
        name: s.name,
        description: s.description,
        ...(s.whenToUse ? { whenToUse: s.whenToUse } : {}),
        modelInvocable: s.invocation.modelInvocable,
      }));
    // 禁用名单同样作用于用户菜单（对齐真宿主：disabled 条目同时离开目录）。
    return { skills: skills.filter((s) => !disabled.has(s.name)) };
  }

  // ── 预设上下文面：设置面板读写 + 注入扩展共享同一份存储 ────────────

  /**
   * 预设上下文的预览 cwd：payload.cwd 显式指定 > 附着会话的 cwd > 默认工作区。
   * 冷会话不为此 attach（预览是轻量读，不应触发会话构建）。
   */
  resolvePresetCwd(payload) {
    const explicit = payload && typeof payload.cwd === "string" && payload.cwd.trim();
    if (explicit) return path.resolve(explicit);
    const sessionId = payload && typeof payload.sessionId === "string" ? payload.sessionId : "";
    const state = sessionId ? this.sessions.get(sessionId) : undefined;
    if (state && state.cwd) return state.cwd;
    return this.defaultWorkspace().path;
  }

  /**
   * presetContext.get：当前配置 + 逐工作区上下文文件扫描 + 注入预览 + 会话勾选。
   * payload.sessionId 给定时按该会话的显式/默认勾选返回 selected 与预览；
   * 未给定时（设置面板场景）selected 返回默认勾选，预览按全部预设启用组装。
   * AGENTS.md/CLAUDE.md 开关是全局的，但文件本身按会话所在工作区解析——
   * 面板因此展示每个工作区的命中情况。面板打开时调用一次；无轮询。
   */
  async presetContextGet(payload) {
    const cwd = this.resolvePresetCwd(payload);
    const sessionId = payload && typeof payload.sessionId === "string" ? payload.sessionId : "";
    const config = this.presetStore.readConfig();
    const statFile = (file) => {
      let stat = null;
      try {
        stat = fs.statSync(file);
      } catch {
        stat = null;
      }
      return { exists: Boolean(stat), size: stat ? stat.size : 0 };
    };
    // 逐工作区扫描：注入按会话 cwd 现场解析（找到即注入），这里只是把
    // 每个工作区的命中情况展示给设置面板——不再只盯着默认工作区。
    const cwdKey = path.normalize(cwd).toLowerCase();
    const workspaces = this.allWorkspaces().map((workspace) => ({
      workspaceId: workspace.workspaceId,
      title: workspace.title || path.basename(workspace.path) || workspace.path,
      path: workspace.path,
      current: path.normalize(workspace.path).toLowerCase() === cwdKey,
      files: contextFileCandidates(workspace.path).map((candidate) => ({
        key: candidate.key,
        label: candidate.label,
        path: candidate.path,
        ...statFile(candidate.path),
      })),
    }));
    const files = contextFileCandidates(cwd).map((candidate) => ({
      key: candidate.key,
      label: candidate.label,
      path: candidate.path,
      ...statFile(candidate.path),
    }));
    const selected = sessionId
      ? this.presetStore.selectionFor(sessionId)
      : config.defaultSelected.slice();
    const previewIds = sessionId
      ? selected
      : config.presets.map((preset) => preset.id);
    return {
      cwd,
      config,
      files,
      workspaces,
      selected,
      preview: this.presetStore.buildBlockFor(cwd, previewIds),
    };
  }

  /**
   * presetContext.set：全量替换预设目录（预设分组/规则/默认勾选/文件勾选；
   * 会话勾选记录由存储层原样保留）。写穿全局设置文件并失效缓存，下一条
   * 消息即生效。返回刷新后的配置（含补齐的 id，供 UI 同步）。
   */
  async presetContextSet(payload) {
    const { config, error } = normalizePresetInput(payload);
    if (error) {
      return { ok: false, error: { code: "bad-request", message: error, details: { issues: [error] } } };
    }
    const stored = this.presetStore.saveConfig(config);
    return { config: stored };
  }

  /**
   * presetContext.select：保存某会话的预设多选勾选（显式记录，空数组 =
   * 该会话不注入任何预设）。返回生效 id 与该会话的注入预览。
   */
  async presetContextSelect(payload) {
    const sessionId = payload && typeof payload.sessionId === "string" ? payload.sessionId : "";
    const presetIds = payload && Array.isArray(payload.presetIds) ? payload.presetIds : [];
    const result = this.presetStore.saveSelection(sessionId, presetIds);
    if (result.error) {
      return { ok: false, error: { code: "bad-request", message: result.error, details: { issues: [result.error] } } };
    }
    const cwd = this.resolvePresetCwd({ sessionId });
    return { selected: result.ids, preview: this.presetStore.buildBlockFor(cwd, result.ids) };
  }

  /** 预设上下文扩展工厂（buildSession 的 extensionFactories 用）。 */
  presetContextExtensionFactory() {
    return createPresetContextExtension({ store: this.presetStore });
  }

  // ── 模型目录 ─────────────────────────────────────────────────────

  /** 模型目录：只列用户在 pi models.json 里配置的服务商（不含内置注册表）。 */
  async modelCatalog() {
    const runtime = await this.runtime();
    const piModels = this.readPiModels();
    const groups = [];
    for (const [name, p] of Object.entries(piModels.providers || {})) {
      let models = [];
      try {
        models = runtime.getModels(name) || [];
      } catch {
        models = [];
      }
      if (!models.length) continue;
      groups.push({
        id: name,
        name: name,
        models: models.map((m) => ({
          id: m.id,
          name: m.name || m.id,
          // reasoning.efforts 必须至少 1 项（客户端 zod .min(1) 校验）。
          ...(m.reasoning ? { reasoning: { efforts: [{ id: "high", name: "High" }] } } : {}),
        })),
      });
    }
    return groups;
  }

  /** 默认路由：deepseek 优先（本机主力），否则第一个有模型的组。 */
  fallbackRoute(groups) {
    const preferred = groups.find((g) => g.id === "deepseek") || groups[0];
    if (preferred && preferred.models.length) {
      return { provider: preferred.id, model: preferred.models[0].id };
    }
    return { provider: "unknown", model: "unknown" };
  }

  /** PI_MODEL=provider/model 显式指定（与旧 pi-web 同语义）。 */
  async resolveModel() {
    const cliModel = process.env.PI_MODEL || "";
    if (!cliModel) return undefined;
    const parts = cliModel.split("/");
    if (parts.length !== 2) return undefined;
    const runtime = await this.runtime();
    return runtime.getModel(parts[0], parts[1]);
  }

  // ── Agent preset 面 ──────────────────────────────────────────────

  /** agentPreset.list：pi 侧单一组成，如实映射（authorable=false：pi 无 preset 创作面）。 */
  async agentPresetList() {
    return {
      presets: [
        {
          id: "standard",
          trust: "system",
          isDefault: true,
          name: "pi 标准模式",
          description: "pi 编码 Agent：文件编辑、Shell、文件检索、网页检索、Skills、子代理 + 共享插件库（工具/命令/MCP）+ pi MCP 服务器。",
        },
      ],
      authorable: false,
      hasDocument: false,
    };
  }

  /** agentPreset.select：pi 侧只有一个组成，选择即确认。 */
  async agentPresetSelect(payload) {
    if (String(payload.agentPreset ?? "standard") !== "standard") {
      return { ok: false, error: { code: "internal", message: "pi 桥只有 standard 一种 preset" } };
    }
    return { selected: "standard" };
  }

  // ── 工作区面：pi 会话可落任意 cwd，工作区 = 目录 + 会话分组 ──────

  /** 工作区注册表（dsh-web-settings 的 workspace-registry 键）。 */
  readWorkspaces() {
    const stored = this.readSettings();
    const reg = stored["workspace-registry"];
    return Array.isArray(reg) && reg.every((w) => w && typeof w.workspaceId === "string" && typeof w.path === "string")
      ? reg
      : [];
  }

  writeWorkspaces(reg) {
    const stored = this.readSettings();
    stored["workspace-registry"] = reg;
    this.writeSettings(stored);
  }

  /** 默认工作区（ROOT）——注册表为空时的兜底，且总在列表里。 */
  defaultWorkspace() {
    return {
      workspaceId: "pi-root",
      path: ROOT,
      title: "pi 工作区",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  }

  /** 全部工作区：注册表 ∪ 默认（按 path 去重，默认始终在）。 */
  allWorkspaces() {
    const reg = this.readWorkspaces();
    const seen = new Set([path.normalize(this.defaultWorkspace().path).toLowerCase()]);
    const items = [this.defaultWorkspace()];
    for (const w of reg) {
      const key = path.normalize(w.path).toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      items.push(w);
    }
    return items;
  }

  /** 会话按 cwd 归属工作区（规范路径比较，大小写不敏感）。 */
  workspaceOf(cwd) {
    const target = path.normalize(String(cwd || ROOT)).toLowerCase();
    for (const w of this.allWorkspaces()) {
      if (path.normalize(w.path).toLowerCase() === target) return w;
    }
    return this.defaultWorkspace();
  }

  /** 工作区显示顺序 / 会话顺序 / 归档集（settings 持久化键）。 */
  readWorkspaceOrder() {
    const stored = this.readSettings();
    const order = stored["workspace-order"];
    return Array.isArray(order) ? order.filter((x) => typeof x === "string") : [];
  }
  writeWorkspaceOrder(order) {
    const stored = this.readSettings();
    stored["workspace-order"] = order;
    this.writeSettings(stored);
  }
  readSessionOrders() {
    const stored = this.readSettings();
    const m = stored["workspace-session-orders"];
    return m && typeof m === "object" && !Array.isArray(m) ? m : {};
  }
  writeSessionOrders(m) {
    const stored = this.readSettings();
    stored["workspace-session-orders"] = m;
    this.writeSettings(stored);
  }
  readArchived() {
    const stored = this.readSettings();
    const a = stored["archived-sessions"];
    return new Set(Array.isArray(a) ? a.filter((x) => typeof x === "string") : []);
  }
  writeArchived(set) {
    const stored = this.readSettings();
    stored["archived-sessions"] = [...set];
    this.writeSettings(stored);
  }

  /** workspace.list：真实宿主形态（items + archivedSessionIds）。
   * 分组 = 磁盘会话 + 内存附着会话（pi 空会话不落盘，但客户端靠
   * sessionIds 归属判定会话的工作区——新建会话必须立刻出现在组里）。
   * 工作区按持久化显示顺序排；会话按持久化顺序 + updatedAt；归档过滤。 */
  async workspaceList() {
    const sdk = await this.sdkReady();
    const sessions = await sdk.SessionManager.list(ROOT, SESSION_DIR);
    const archived = this.readArchived();
    const order = this.readWorkspaceOrder();
    const sessionOrders = this.readSessionOrders();
    const groups = new Map();
    // 被删除的默认工作区不再发出分组——除非再没有任何其他工作区可接管：
    // 会话必须落进某个真实分组（客户端的“未分组”桶不允许出现）。
    const defaultHidden = this.readDefaultHidden();
    const defaultId = this.defaultWorkspace().workspaceId;
    const registered = this.allWorkspaces().filter((w) => w.workspaceId !== defaultId);
    const emitDefault = !defaultHidden || registered.length === 0;
    for (const w of this.allWorkspaces()) {
      if (!emitDefault && w.workspaceId === defaultId) continue;
      groups.set(w.workspaceId, { w, sessions: [] });
    }
    // 认领目标：cwd 精确命中的可见组；否则可见的默认组；否则第一个注册组。
    // 兜底永不指向已隐藏的默认工作区（它不在 groups 里，落空即产生未分组）。
    const claimOf = (cwd) => {
      const target = path.normalize(String(cwd || ROOT)).toLowerCase();
      for (const entry of groups.values()) {
        if (path.normalize(entry.w.path).toLowerCase() === target) return entry;
      }
      const fallbackId = !defaultHidden ? defaultId : registered[0]?.workspaceId;
      return fallbackId ? groups.get(fallbackId) : undefined;
    };
    const assign = (cwd, s) => {
      if (archived.has(String(s.id))) return;
      const entry = claimOf(cwd);
      if (entry) entry.sessions.push(s);
    };
    for (const s of sessions.slice(0, 200)) assign(s.cwd, s);
    // 内存附着会话（刚建的空会话等）按其实际 cwd 归组。
    for (const [id, state] of this.sessions) {
      if (archived.has(id)) continue;
      if (sessions.some((s) => String(s.id) === id)) continue;
      assign(state.cwd ?? state.session?.cwd ?? ROOT, { id, modified: new Date(), messageCount: 0 });
    }
    const byId = new Map([...groups.values()].map((e) => [e.w.workspaceId, e]));
    // 持久化顺序优先，未入序的按原顺序补尾。
    const orderedIds = [...order.filter((id) => byId.has(id))];
    for (const id of byId.keys()) if (!orderedIds.includes(id)) orderedIds.push(id);
    const items = [];
    for (const id of orderedIds) {
      const { w, sessions: wsSessions } = byId.get(id);
      const sorted = wsSessions.sort((a, b) => (b.modified?.getTime?.() ?? 0) - (a.modified?.getTime?.() ?? 0));
      let ids = sorted.map((s) => String(s.id));
      // 该工作区的持久化会话顺序（drag 结果）：已存顺序在前，其余按时间补尾。
      const saved = Array.isArray(sessionOrders[id]) ? sessionOrders[id].filter((x) => ids.includes(x)) : [];
      if (saved.length) ids = [...saved, ...ids.filter((x) => !saved.includes(x))];
      items.push({
        workspaceId: w.workspaceId,
        path: w.path,
        title: w.title,
        sessionIds: ids,
        createdAt: w.createdAt,
        updatedAt: sorted[0]?.modified?.toISOString?.() ?? w.updatedAt,
      });
    }
    return { items, archivedSessionIds: [...archived] };
  }

  /** workspace.create：注册新工作区目录（须为已存在的目录）。
   *  默认工作区被删除后，重新 create 同一路径即恢复该组（清除隐藏标记）。 */
  async workspaceCreate(payload) {
    const dir = path.resolve(String(payload.path || ""));
    if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
      return { ok: false, error: { code: "workspace-invalid-path", message: `目录不存在：${dir}`, details: { path: dir } } };
    }
    const d = this.defaultWorkspace();
    if (this.readDefaultHidden() && path.normalize(dir).toLowerCase() === path.normalize(d.path).toLowerCase()) {
      this.writeDefaultHidden(false);
      const view = {
        workspaceId: d.workspaceId,
        path: d.path,
        title: d.title,
        sessionIds: [],
        createdAt: d.createdAt,
        updatedAt: new Date().toISOString(),
      };
      this.pushHost({ type: "host/workspace-changed", workspace: view });
      return { workspace: view, created: true };
    }
    const reg = this.readWorkspaces();
    if (this.allWorkspaces().some((w) => path.normalize(w.path).toLowerCase() === path.normalize(dir).toLowerCase())) {
      return { ok: false, error: { code: "workspace-name-conflict", message: `该目录已是工作区：${dir}`, details: { name: dir } } };
    }
    const workspace = {
      workspaceId: `ws-${crypto.randomUUID()}`,
      path: dir,
      title: path.basename(dir) || dir,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    reg.push(workspace);
    this.writeWorkspaces(reg);
    // 真宿主形态：{workspace: WorkspaceView, created: true}。
    const view = {
      workspaceId: workspace.workspaceId,
      path: workspace.path,
      title: workspace.title,
      sessionIds: [],
      createdAt: workspace.createdAt,
      updatedAt: workspace.updatedAt,
    };
    this.pushHost({ type: "host/workspace-changed", workspace: view });
    return { workspace: view, created: true };
  }

  /** workspace.rename：改标题（默认工作区也允许），返回真宿主的完整视图形态。 */
  async workspaceRename(payload) {
    const id = String(payload.workspaceId ?? "");
    const all = this.allWorkspaces();
    const target = all.find((w) => w.workspaceId === id);
    if (!target) {
      return { ok: false, error: { code: "workspace-not-found", message: `工作区不存在：${id}`, details: { workspaceId: id } } };
    }
    const title = String(payload.title || target.title);
    if (id === this.defaultWorkspace().workspaceId) {
      const stored = this.readSettings();
      stored["workspace-title"] = { title };
      this.writeSettings(stored);
    } else {
      const reg = this.readWorkspaces();
      const row = reg.find((w) => w.workspaceId === id);
      if (row) {
        row.title = title;
        row.updatedAt = new Date().toISOString();
        this.writeWorkspaces(reg);
      }
    }
    // 真宿主形态：{workspace: WorkspaceView}。
    const view = {
      workspaceId: id,
      path: target.path,
      title,
      sessionIds: [],
      createdAt: target.createdAt,
      updatedAt: new Date().toISOString(),
    };
    this.pushHost({ type: "host/workspace-changed", workspace: view });
    return { workspace: view };
  }

  /** workspace.delete：删除只把工作区从列表移除；其会话立即并入接管组
   *  （可见的默认组，默认组不可见时为第一个注册组），并即时推送归属帧——
   *  客户端收到 removed 帧会立刻删组，没有新的 workspace-changed 帧，
   *  组内会话在下次刷新前会全部落“未分组”。会话必须有真实分组，未分组桶不允许出现。
   *  默认工作区（pi-root）同样可删：持久化一个隐藏标记，列表不再发出该组；
   *  重新 create 同路径即恢复。默认组是唯一工作区时删除为 no-op
   *  （没有接管组可收留其会话，分组保留以避免未分组）。 */
  async workspaceDelete(payload) {
    const id = String(payload.workspaceId ?? "");
    const isDefault = id === this.defaultWorkspace().workspaceId;
    if (isDefault && this.allWorkspaces().length === 1) {
      // 唯一工作区不可删：无接管组，删了会话就要落未分组。
      this.pushHost({ type: "host/workspace-changed", workspace: await this.workspaceViewOf(id) });
      return { deleted: true };
    }
    // 删除前抓走本组会话，删除后逐个推送其新归属组的最新视图。
    const affected = await this.sessionIdsOfGroup(id);
    if (isDefault) {
      this.writeDefaultHidden(true);
      const order = this.readWorkspaceOrder().filter((x) => x !== id);
      this.writeWorkspaceOrder(order);
      this.pushHost({ type: "host/workspace-removed", workspaceId: id });
    } else {
      const reg = this.readWorkspaces();
      const next = reg.filter((w) => w.workspaceId !== id);
      if (next.length === reg.length) {
        return { ok: false, error: { code: "workspace-not-found", message: `工作区不存在：${id}`, details: { workspaceId: id } } };
      }
      this.writeWorkspaces(next);
      // 同步从显示顺序里移除。
      const order = this.readWorkspaceOrder().filter((x) => x !== id);
      this.writeWorkspaceOrder(order);
      this.pushHost({ type: "host/workspace-removed", workspaceId: id });
    }
    for (const sessionId of affected) void this.pushHostWorkspaceOf(sessionId);
    return { deleted: true };
  }

  /** 某工作区当前分组的会话 id（workspace.list 快照）。 */
  async sessionIdsOfGroup(workspaceId) {
    try {
      const { items } = await this.workspaceList();
      return items.find((i) => i.workspaceId === workspaceId)?.sessionIds ?? [];
    } catch {
      return [];
    }
  }

  /** 工作区视图（workspace.list 快照中的行；找不到给最小形态）。 */
  async workspaceViewOf(workspaceId) {
    const { items } = await this.workspaceList();
    return (
      items.find((i) => i.workspaceId === workspaceId) ?? {
        workspaceId,
        path: "",
        title: "",
        sessionIds: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    );
  }

  /** 默认工作区被删除后的隐藏标记（删除只是移除分组，文件夹与会话保留；
   *  会话由 workspaceList 的认领兜底并入接管组，不落未分组）。 */
  readDefaultHidden() {
    const stored = this.readSettings();
    return stored["workspace-default-hidden"] === true;
  }

  writeDefaultHidden(hidden) {
    const stored = this.readSettings();
    if (hidden) stored["workspace-default-hidden"] = true;
    else delete stored["workspace-default-hidden"];
    this.writeSettings(stored);
  }

  /** workspace.insertBefore：工作区拖拽排序（锚点省略 = 追加末尾；返回完整顺序）。 */
  async workspaceInsertBefore(payload) {
    const id = String(payload.workspaceId ?? "");
    const anchor = payload.beforeWorkspaceId ? String(payload.beforeWorkspaceId) : null;
    const all = this.allWorkspaces().map((w) => w.workspaceId);
    if (!all.includes(id)) {
      return { ok: false, error: { code: "workspace-not-found", message: `工作区不存在：${id}`, details: { workspaceId: id } } };
    }
    if (anchor && !all.includes(anchor)) {
      return { ok: false, error: { code: "workspace-not-found", message: `锚点工作区不存在：${anchor}`, details: { workspaceId: anchor } } };
    }
    const base = this.readWorkspaceOrder().filter((x) => all.includes(x));
    for (const x of all) if (!base.includes(x)) base.push(x);
    base.splice(base.indexOf(id), 1);
    if (anchor) base.splice(base.indexOf(anchor), 0, id);
    else base.push(id);
    this.writeWorkspaceOrder(base);
    this.pushHost({ type: "host/workspace-order-changed", workspaceIds: base });
    return { workspaceIds: base };
  }

  /** workspace.insertSessionBefore：工作区内会话排序（返回完整 WorkspaceView）。 */
  async workspaceInsertSessionBefore(payload) {
    const wsId = String(payload.workspaceId ?? "");
    const sid = String(payload.sessionId ?? "");
    const anchor = payload.beforeSessionId ? String(payload.beforeSessionId) : null;
    const { items } = await this.workspaceList();
    const item = items.find((i) => i.workspaceId === wsId);
    if (!item) {
      return { ok: false, error: { code: "workspace-not-found", message: `工作区不存在：${wsId}`, details: { workspaceId: wsId } } };
    }
    const base = item.sessionIds.slice();
    if (!base.includes(sid)) base.push(sid);
    base.splice(base.indexOf(sid), 1);
    if (anchor && base.includes(anchor)) base.splice(base.indexOf(anchor), 0, sid);
    else base.push(sid);
    const orders = this.readSessionOrders();
    orders[wsId] = base;
    this.writeSessionOrders(orders);
    const view = { ...item, sessionIds: base };
    this.pushHost({ type: "host/workspace-changed", workspace: view });
    return { workspace: view };
  }

  /** workspace.archiveSession：会话归档（从列表隐藏；返回完整归档集）。 */
  async archiveSession(payload) {
    const sid = String(payload.sessionId ?? "");
    const set = this.readArchived();
    set.add(sid);
    this.writeArchived(set);
    this.pushHost({ type: "host/archived-sessions-changed", archivedSessionIds: [...set] });
    return { archivedSessionIds: [...set] };
  }

  /** workspace.unarchiveSession：取消归档。 */
  async unarchiveSession(payload) {
    const sid = String(payload.sessionId ?? "");
    const set = this.readArchived();
    set.delete(sid);
    this.writeArchived(set);
    this.pushHost({ type: "host/archived-sessions-changed", archivedSessionIds: [...set] });
    return { archivedSessionIds: [...set] };
  }

  // ── host 目录浏览面（pi 即本地进程，文件系统直读） ────────────────

  /** host.listDirectory：单层目录 + 祖先链（真宿主 DirectoryListing 形态；
   *  与真宿主一致可浏览任意全路径，默认列出用户主目录）。 */
  async listDirectory(payload) {
    const os = require("node:os");
    const home = os.homedir();
    const target = payload.path === undefined || payload.path === ""
      ? home
      : path.resolve(String(payload.path));
    let dirents;
    try {
      dirents = fs.readdirSync(target, { withFileTypes: true });
    } catch {
      return { ok: false, error: { code: "directory-unreadable", message: `无法读取目录：${target}`, details: { path: target } } };
    }
    const entries = dirents
      .filter((d) => d.isDirectory() || d.isSymbolicLink())
      .map((d) => ({
        name: d.name,
        path: path.join(target, d.name),
        hidden: d.name.startsWith("."),
      }))
      .sort((a, b) => a.name.localeCompare(b.name, "zh-Hans-CN"));
    // 祖先链：从盘符根到 target（含），全部可作为跳转面包屑。
    const crumbs = [];
    let cursor = target;
    while (true) {
      crumbs.unshift({ name: cursor, path: cursor, hidden: false });
      const parent = path.dirname(cursor);
      if (parent === cursor) break;
      cursor = parent;
    }
    return {
      path: target,
      home,
      crumbs,
      entries: entries.slice(0, 500),
      truncated: entries.length > 500,
    };
  }

  /** host.createDirectory：父目录下建一个子目录（与真宿主一致，无范围限制）。 */
  async createDirectory(payload) {
    const parent = path.resolve(String(payload.path || ""));
    const name = String(payload.name || "").trim();
    if (!name || name.includes("/") || name.includes("\\") || name.includes("..")) {
      return { ok: false, error: { code: "directory-create-failed", message: "非法目录名" } };
    }
    const child = path.join(parent, name);
    if (fs.existsSync(child)) {
      return { ok: false, error: { code: "directory-exists", message: `目录已存在：${name}`, details: { path: path.join(parent, name) } } };
    }
    try {
      fs.mkdirSync(child);
    } catch {
      return { ok: false, error: { code: "directory-create-failed", message: `建目录失败：${name}` } };
    }
    return { path: child };
  }

  /**
   * host.pickDirectory：Windows 原生文件夹选择对话框（同真 dsh 的 native 后端语义）。
   * 经 powershell FolderBrowserDialog 弹窗；用户取消返回 null。
   */
  async pickDirectory() {
    if (process.platform !== "win32") {
      return { ok: false, error: { code: "directory-picker-unavailable", message: "pi 桥的目录选择器仅支持 Windows", details: { capability: "pickDirectory" } } };
    }
    const script = [
      "Add-Type -AssemblyName System.Windows.Forms | Out-Null",
      "$d = New-Object System.Windows.Forms.FolderBrowserDialog",
      "$d.Description = 'pi：选择工作区目录'",
      "if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }",
    ].join("; ");
    const { execFile } = require("node:child_process");
    return new Promise((resolve) => {
      execFile("powershell.exe", ["-NoProfile", "-STA", "-Command", script], { timeout: 10 * 60 * 1000, windowsHide: true }, (error, stdout) => {
        if (error) {
          resolve({ ok: false, error: { code: "internal", message: `目录选择器失败：${error.message}` } });
          return;
        }
        const picked = String(stdout || "").trim();
        // 取消返回 null（dsh 契约：cancellation returns null）。
        resolve({ path: picked || null });
      });
    });
  }

  /** host.openPath：无桌面交付能力，如实报告。 */
  openPath() {
    return { ok: false, error: { code: "internal", message: "pi 桥不支持调用系统应用打开路径" } };
  }

  // ── goal 面：目标驱动循环（含 relentless 模式：不完成不准停） ────

  /**
   * GoalManager 语义：
   * - create: 建目标（objective + maxGoalRounds + mode: normal|relentless）
   *   创建即激活 round-driver：自动循环发“推进目标”提示，每轮结束评估——
   *   模型输出含完成标记（GOAL_STATE: complete）则 complete；
   *   relentless 模式未完成自动开下一轮直到 complete / pause / clear。
   * - pause/resume/complete/clear: 桥内状态机。
   * - 状态经 session/projection 的 goal key 推送（goal 面板数据源）。
   */
  goalProjection(sessionId) {
    const g = this.goals && this.goals.get(sessionId);
    if (!g) return null;
    return {
      goal: {
        id: g.id,
        revision: g.revision,
        objective: g.objective,
        phase: g.phase,
        ...(g.maxGoalRounds ? { maxGoalRounds: g.maxGoalRounds } : { maxGoalRounds: 100 }),
      },
      roundsStarted: g.roundsStarted,
      createdAt: g.createdAt,
      updatedAt: g.updatedAt,
    };
  }

  pushGoalProjection(sessionId) {
    const value = this.goalProjection(sessionId);
    if (!value) return;
    const state = this.sessions.get(sessionId);
    this.pushMux({
      type: "session/projection",
      sessionId,
      key: "goal",
      value,
      seq: state ? state.seq : 0,
    });
  }

  async goalCreate(args, sessionId) {
    this.goals = this.goals || new Map();
    const id = `goal-${crypto.randomUUID().slice(0, 8)}`;
    const goal = {
      id,
      revision: 1,
      objective: String(args?.objective ?? ""),
      phase: "active",
      maxGoalRounds: Number(args?.maxGoalRounds ?? 100),
      mode: args?.mode === "relentless" ? "relentless" : "normal",
      roundsStarted: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    this.goals.set(sessionId, goal);
    this.pushGoalProjection(sessionId);
    // 启动 round-driver（异步推进，不阻塞 RPC 返回）。
    setImmediate(() => this.goalDrive(sessionId));
    return { ref: { id, revision: goal.revision } };
  }

  /** 单轮推进：给会话发目标提示，等待回合结束，评估完成标记。 */
  async goalDrive(sessionId) {
    const goal = this.goals && this.goals.get(sessionId);
    if (!goal || goal.phase !== "active") return;
    const state = await this.ensureSession(sessionId).catch(() => null);
    if (!state) return;
    goal.roundsStarted += 1;
    goal.updatedAt = Date.now();
    goal.revision += 1;
    this.pushGoalProjection(sessionId);
    if (goal.roundsStarted > goal.maxGoalRounds) {
      goal.phase = "blocked";
      goal.blockedReason = { code: "rounds-exhausted", message: `已达轮次上限（${goal.maxGoalRounds}）` };
      this.pushGoalProjection(sessionId);
      this.notifyGoalSettled(goal, "blocked");
      return;
    }
    const prompt = [
      `【目标推进 · 第 ${goal.roundsStarted} 轮】`,
      `当前目标：${goal.objective}`,
      `请继续朝目标推进，完成实际工作（可用任何工具）。`,
      goal.mode === "relentless"
        ? "这是强制完成模式：不允许宣布放弃或推迟；若本轮未能完成全部工作，说明剩余部分并继续执行。"
        : "",
      `当你确认目标已全部完成时，在回复的最后一行输出：GOAL_STATE: complete`,
      `若确认目标无法完成（需要外部条件、方向错误、反复失败），最后一行输出：GOAL_STATE: blocked <一句话原因>`,
    ].filter(Boolean).join("\n");
    // 订阅本轮结束（agent_end）后评估；本轮结束即注销，避免逐轮累积
    // （否则 relentless 模式下旧轮 evaluate 仍挂着，一次 agent_end 触发
    // N 个 goalEvaluate，驱动器指数级自我复制）。
    const unsub = this.translateEventReal(sessionId, (ev) => {
      if (ev.type !== "agent_end") return;
      unsub();
      setImmediate(() => this.goalEvaluate(sessionId));
    });
    state.session.prompt(prompt).catch((error) => {
      const message = error instanceof Error ? error.message : String(error);
      console.error("[goal] round prompt failed:", message);
      // 驱动器停摆是真实失败：推系统通知，别让目标无声卡死。
      this.notifyPortal("pi 任务失败 ✗", `${String(goal.objective || "").slice(0, 60)}：本轮推进请求失败（${message.slice(0, 120)}）`);
    });
  }

  /** 评估上一轮：查会话尾部的模型自评；relentless 未完成自动续轮。 */
  async goalEvaluate(sessionId) {
    const goal = this.goals && this.goals.get(sessionId);
    if (!goal || goal.phase !== "active") return;
    const state = this.sessions.get(sessionId);
    if (!state) return;
    // 从本会话 pi 的消息分支尾部找最后一条 assistant 文本。
    const branch = state.session?.sessionManager?.getBranch?.() || [];
    let lastAssistant = "";
    for (const entry of branch) {
      const m = entry.message;
      if (m && m.role === "assistant" && Array.isArray(m.content)) {
        const text = m.content.filter((c) => c.type === "text").map((c) => c.text).join("");
        if (text) lastAssistant = text;
      }
    }
    const done = /GOAL_STATE:\s*complete/i.test(lastAssistant);
    if (done) {
      goal.phase = "complete";
      goal.updatedAt = Date.now();
      goal.revision += 1;
      this.pushGoalProjection(sessionId);
      this.notifyGoalSettled(goal, "complete");
      return;
    }
    // 与 complete 对称的失败出口：模型自报无法完成（可带原因）。
    const blocked = lastAssistant.match(/GOAL_STATE:\s*blocked\s*([^\n]*)/i);
    if (blocked) {
      this.goalBlocked(blocked[1] && blocked[1].trim() ? blocked[1].trim() : "模型自报目标无法完成", sessionId);
      return;
    }
    if (goal.mode === "relentless") {
      // 不完成不准停：自动开下一轮（间隔让 UI 喘口气）。
      setTimeout(() => this.goalDrive(sessionId), 1500);
    } else {
      // normal 模式：等用户手动 resume 下一轮。
      goal.phase = "paused";
      goal.updatedAt = Date.now();
      goal.revision += 1;
      this.pushGoalProjection(sessionId);
    }
  }

  async goalEdit(args, sessionId) {
    const goal = this.goals && this.goals.get(sessionId);
    if (!goal) return { ok: false, error: { code: "internal", message: "该会话没有活动目标" } };
    if (args?.objective !== undefined) goal.objective = String(args.objective);
    if (args?.maxGoalRounds !== undefined) goal.maxGoalRounds = Number(args.maxGoalRounds);
    goal.revision += 1;
    goal.updatedAt = Date.now();
    this.pushGoalProjection(sessionId);
    return { ref: { id: goal.id, revision: goal.revision } };
  }

  async goalPause(args, sessionId) {
    const goal = this.goals && this.goals.get(sessionId);
    if (!goal) return { ok: false, error: { code: "internal", message: "该会话没有活动目标" } };
    goal.phase = "paused";
    goal.revision += 1;
    goal.updatedAt = Date.now();
    this.pushGoalProjection(sessionId);
    return { ref: { id: goal.id, revision: goal.revision } };
  }

  async goalResume(args, sessionId) {
    const goal = this.goals && this.goals.get(sessionId);
    if (!goal) return { ok: false, error: { code: "internal", message: "该会话没有活动目标" } };
    if (goal.phase !== "paused") return { ok: false, error: { code: "internal", message: "只有暂停中的目标可以恢复" } };
    goal.phase = "active";
    goal.revision += 1;
    goal.updatedAt = Date.now();
    this.pushGoalProjection(sessionId);
    setImmediate(() => this.goalDrive(sessionId));
    return { ref: { id: goal.id, revision: goal.revision } };
  }

  async goalComplete(args, sessionId) {
    const goal = this.goals && this.goals.get(sessionId);
    if (!goal) return { ok: false, error: { code: "internal", message: "该会话没有活动目标" } };
    goal.phase = "complete";
    goal.revision += 1;
    goal.updatedAt = Date.now();
    this.pushGoalProjection(sessionId);
    this.notifyGoalSettled(goal, "complete");
    return { ref: { id: goal.id, revision: goal.revision } };
  }

  /** 目标受阻（模型自报 blocked / 轮次耗尽的统一出口）：推失败通知。 */
  goalBlocked(reason, sessionId) {
    const goal = this.goals && this.goals.get(sessionId);
    if (!goal || goal.phase === "blocked") return;
    goal.phase = "blocked";
    goal.blockedReason = { code: "model-reported", message: String(reason || "目标受阻") };
    goal.revision += 1;
    goal.updatedAt = Date.now();
    this.pushGoalProjection(sessionId);
    this.notifyGoalSettled(goal, "blocked");
  }

  async goalClear(args, sessionId) {
    if (this.goals) this.goals.delete(sessionId);
    // 清空投影：goal key 推 null（面板收到 null 显示无目标）。
    this.pushMux({ type: "session/projection", sessionId, key: "goal", value: null, seq: 0 });
    return { cleared: true };
  }

  /** translateEvent 的旁路：goal 的 evaluate 监听器直接吃 pi 原始事件。
   *  返回注销函数（调用方必须在轮次结束时注销，否则监听器泄漏）。 */
  translateEventReal(sessionId, handler) {
    const state = this.sessions.get(sessionId);
    if (!state || !state.session) return () => {};
    return state.session.subscribe(handler);
  }

  // ── 子代理面：桥内注册表（pi-subagents 扩展在 agent 内部处理 spawn） ──

  async subagentList(payload) {
    // pi 的子代理由 agent 内部扩展管理，桥不跟踪——空目录（面板显示无子代理）。
    return { entries: [], parentAvailable: true };
  }

  async subagentHistory(payload) {
    return { ok: false, error: { code: "subagent-not-found", message: "pi 桥暂无该子代理的记录", details: { parentSessionId: String(payload?.parentSessionId ?? ""), childSessionId: String(payload?.childSessionId ?? "") } } };
  }

  async subagentPrompt(payload) {
    return { ok: false, error: { code: "subagent-not-found", message: "pi 桥暂不支持向子代理发消息（子代理由 agent 内部扩展管理）", details: { parentSessionId: String(payload?.parentSessionId ?? ""), childSessionId: String(payload?.childSessionId ?? "") } } };
  }

  async subagentInterrupt(payload) {
    return { accepted: true };
  }

  // ── 会话构建 ──────────────────────────────────────────────────────

  /** 精确启用的 pi 官方/社区扩展（用户“标准模式”能力面）：
   *  noExtensions 只关全局扫描装载；这几个显式列出的扩展经
   *  additionalExtensionPaths 精确装载（性能不受全局拖累）。 */
  curatedExtensionPaths() {
    const base = path.join(AGENT_DIR, "npm", "node_modules");
    const wanted = [
      "pi-web-access",       // 网页检索
      "pi-subagents",        // 子代理
      "@vigolium/piolium",   // pi 官方扩展集（含 todo 等）
    ];
    const paths = [];
    for (const name of wanted) {
      const dir = path.join(base, ...name.split("/"));
      if (fs.existsSync(dir)) paths.push(dir);
    }
    return paths;
  }

  async buildSession(cwd, sessionManager) {
    const t0 = Date.now();
    const stamp = (label) => console.log(`[perf] buildSession ${label}: ${Date.now() - t0}ms`);
    const sdk = await this.sdkReady();
    stamp("sdk");
    const runtime = await this.runtime();
    stamp("runtime");
    const { createPiAdapter } = await import("@mcca/pi-adapter");
    const { createPiMcpExtension, readMcpServers } = await import("@mcca/pi-mcp");
    stamp("adapters-import");
    // MCP 注册表过滤：管理面板禁用的服务器不进 pi 会话的装载名单
    //（对齐真宿主 setEnabled 热应用的语义——禁用即离开工具面）。
    const mcpDisabled = new Set(this.readMcpDisabled());
    const mcpServers = readMcpServers(path.join(ROOT, "config", "mcp.json"))
      .filter((cfg) => !mcpDisabled.has(cfg.serverName));
    const piAdapter = createPiAdapter({
      pluginsDir: path.join(ROOT, "plugins"),
      configPath: path.join(ROOT, "config", "plugins.json"),
      cwd: ROOT,
      onMcpServer: (cfg) => mcpServers.push(cfg),
    });
    const piMcp = createPiMcpExtension({ servers: mcpServers, cwd: ROOT });
    stamp("adapters-construct");
    const resourceLoader = new sdk.DefaultResourceLoader({
      cwd,
      agentDir: AGENT_DIR,
      // 性能关键：跳过 pi 全局扩展装载与重资源（themes/prompts/context）。
      // 技能保留（共享库在用）；组成走 extensionFactories +
      // curatedExtensionPaths（网页检索/子代理等标准模式能力）。
      noExtensions: true,
      noPromptTemplates: true,
      noThemes: true,
      noContextFiles: true,
      additionalExtensionPaths: this.curatedExtensionPaths(),
      additionalSkillPaths: [path.join(ROOT, "skills")].filter((p) => fs.existsSync(p)),
      extensionFactories: [
        { name: "mcca-pi-adapter", factory: piAdapter },
        { name: "mcca-pi-mcp", factory: piMcp },
        // 预设上下文注入：before_agent_start 每条消息追加启用项（空配置零开销）。
        { name: "mcca-preset-context", factory: this.presetContextExtensionFactory() },
      ],
    });
    await resourceLoader.reload();
    stamp("loader-reload");
    // 包装 SettingsManager：把设置的压缩阈值百分比换算成 reserveTokens
    // （= 当前模型 contextWindow × (1 − pct/100)），对会话当前模型即时生效。
    // 其余设置方法原样转发到真实 manager（全局/项目 settings.json 读取等）。
    const sessionRef = { session: null };
    const bridge = this;
    let settingsManager;
    try {
      const base = await sdk.SettingsManager.create(cwd, AGENT_DIR);
      settingsManager = new Proxy(base, {
        get(target, prop) {
          if (prop === "getCompactionSettings") {
            return () => {
              const settings = target.getCompactionSettings();
              const model = sessionRef.session && sessionRef.session.model;
              const pct = model ? bridge.thresholdPercentFor(model.provider, model.id) : undefined;
              if (!model || !model.contextWindow || pct === undefined) return settings;
              const reserve = Math.max(0, Math.floor(model.contextWindow * (1 - pct / 100)));
              return { ...settings, reserveTokens: reserve };
            };
          }
          const value = Reflect.get(target, prop);
          return typeof value === "function" ? value.bind(target) : value;
        },
      });
    } catch (error) {
      console.error("[pi-bridge] SettingsManager wrap failed, using pi defaults:", error instanceof Error ? error.message : String(error));
    }
    const session = await sdk.createAgentSession({
      sessionManager: sessionManager ?? sdk.SessionManager.create(cwd, SESSION_DIR),
      modelRuntime: runtime,
      // 不猜默认模型：pi 依自身配置选（PI_MODEL 可显式覆盖）。
      model: await this.resolveModel(),
      cwd,
      resourceLoader,
      ...(settingsManager ? { settingsManager } : {}),
    });
    stamp("createAgentSession");
    sessionRef.session = session;
    return session;
  }

  // ── 会话生命周期 ────────────────────────────────────────────────

  async createSession(payload, opts) {
    const warmup = Boolean(opts && opts.warmup);
    // dsh 语义：带 workspaceId 的会话落该工作区的 cwd；缺省落默认工作区。
    const workspaceId = String(payload?.workspaceId ?? "");
    let cwd = this.defaultWorkspace().path;
    if (workspaceId) {
      const target = this.allWorkspaces().find((w) => w.workspaceId === workspaceId);
      if (!target) {
        return { ok: false, error: { code: "workspace-not-found", message: `工作区不存在：${workspaceId}`, details: { workspaceId } } };
      }
      cwd = target.path;
    }
    const { session } = await this.buildSession(cwd);
    const id = session.sessionId;
    // cwd 存进 state（pi 的 session 对象不保证透传 cwd 属性）——
    // list/workspace 分组以创建时指定的工作目录为准。
    const state = { session, unsubscribe: null, seq: 0, turn: 0, streaming: null, cwd, modelsMtime: this.currentModelsMtime() };
    this.sessions.set(id, state);
    state.unsubscribe = session.subscribe((event) => this.translateEvent(id, event));
    if (warmup) {
      // 预热会话：不广播、立即释放，不进列表（避免残留空白会话）。
      this.sessions.delete(id);
      if (typeof state.unsubscribe === "function") state.unsubscribe();
      return { sessionId: id };
    }
    // 开场基线帧延后到 RPC 响应之后：HTTP 响应必须先于 WS 帧到达
    // 客户端（真宿主同样保证 create 应答先落地），否则客户端在还没登记
    // 新会话时就收到 mux 帧会形成 scope 竞态。
    setImmediate(() => {
      if (!this.sessions.has(id)) return;
      this.pushMux({ type: "session/subscribed", sessionId: id, lastSeq: -1 });
      // host 注册帧：新会话摘要（cwd 供客户端认领）+ 所在工作区的最新视图
      //（客户端工作区分组只认 host 通道的这两类帧，不发就落“未分组”）。
      this.pushHost({ type: "host/session-added", sessionId: id, blank: true, cwd, agentPreset: "standard" });
      void this.pushHostWorkspaceOf(id);
      // 开场基线帧（对齐真宿主新会话序列）。权限预设/沙箱模式/权限投影**不发**：
      // pi 无沙箱与权限档位概念，客户端的 Access 芯片与 /permission 装饰只认
      // permissions 投影（投影缺席 = 芯片不渲染），发假值只会造出一个点了没用的
      // 开关。权限设置整行也随 boot 图的 ui-permission-presets 行一并移除。
    });
    return { sessionId: id, agentPreset: "standard" };
  }

  async listSessions() {
    const sdk = await this.sdkReady();
    const sessions = await sdk.SessionManager.list(ROOT, SESSION_DIR);
    this.sessionPaths.clear();
    const archived = this.readArchived();
    const items = sessions.slice(0, 200).map((s) => {
      if (s.id && s.path) this.sessionPaths.set(String(s.id), String(s.path));
      return {
        sessionId: String(s.id),
        updatedAt: s.modified?.getTime?.() ?? s.created?.getTime?.() ?? 0,
        running: this.sessions.has(String(s.id)) && Boolean(this.sessions.get(String(s.id)).session?.isStreaming),
        blank: (s.messageCount ?? 0) === 0,
        cwd: s.cwd ?? ROOT,
      };
    }).filter((i) => !archived.has(i.sessionId));
    // 内存附着会话合并（pi 的空会话不落盘——首条消息才写文件，
    // 刚建的会话只有内存态；dsh 客户端 open 依赖 list 快照包含它）。
    for (const [id, state] of this.sessions) {
      if (archived.has(id)) continue;
      if (items.some((i) => i.sessionId === id)) continue;
      items.push({
        sessionId: id,
        updatedAt: Date.now(),
        running: Boolean(state.session?.isStreaming),
        blank: !state.turn,
        cwd: state.cwd ?? ROOT,
      });
    }
    items.sort((a, b) => b.updatedAt - a.updatedAt);
    return { items };
  }

  /** 冷会话文件解析：优先内存态，否则刷新磁盘索引。 */
  async resolveSessionFile(sessionId) {
    const id = String(sessionId);
    if (this.sessionPaths.has(id)) return this.sessionPaths.get(id);
    await this.listSessions();
    return this.sessionPaths.get(id) ?? null;
  }

  /**
   * 会话删除（归档页删除按钮的宿主语义）：拒绝运行中的会话；删除磁盘文件；
   * 摘除归档集；推 host/session-removed + host/archived-sessions-changed +
   * 所属组的最新 workspace 视图——客户端三帧即时收敛，不产生未分组空窗。
   * 与 dsh 侧 /mcca/sessions/delete 路由同语义（packages/session-delete）。
   */
  async sessionDelete(payload) {
    const id = String(payload?.sessionId ?? "");
    if (!id) {
      return { ok: false, error: { code: "session-id-required", message: "sessionId is required" } };
    }
    const state = this.sessions.get(id);
    if (state?.session?.isStreaming) {
      return { ok: false, error: { code: "session-running", message: "会话正在运行，先停止再删除" } };
    }
    const file = await this.resolveSessionFile(id);
    if (!file && !state) {
      return { ok: false, error: { code: "session-not-found", message: `no persisted session ${id}` } };
    }
    // 归属组在删除前解析（删除后组关系变化）。
    const { items } = await this.workspaceList();
    const group = items.find((i) => i.sessionIds.includes(id));
    if (state) {
      this.sessions.delete(id);
      if (typeof state.unsubscribe === "function") state.unsubscribe();
    }
    if (file) {
      try {
        fs.rmSync(file, { force: true });
      } catch (error) {
        return { ok: false, error: { code: "delete-failed", message: error instanceof Error ? error.message : String(error) } };
      }
    }
    this.sessionPaths.delete(id);
    const archived = this.readArchived();
    if (archived.has(id)) {
      archived.delete(id);
      this.writeArchived(archived);
    }
    this.pushHost({ type: "host/session-removed", sessionId: id });
    this.pushHost({ type: "host/archived-sessions-changed", archivedSessionIds: [...this.readArchived()] });
    if (group) {
      const fresh = await this.workspaceList();
      const view = fresh.items.find((i) => i.workspaceId === group.workspaceId);
      if (view) this.pushHost({ type: "host/workspace-changed", workspace: view });
    }
    return { deleted: true };
  }

  /**
   * dsh history：整段 jsonl 分页语义 MVP 化为“一页全量 + 事件翻译”。
   * 附着会话读内存分支；冷会话 SessionManager.open 直读磁盘（不建 agent）。
   */
  async history(payload) {
    const id = String(payload.sessionId);
    const state = this.sessions.get(id);
    let branch;
    if (state) {
      // fork 子会话注册时 session 为 null（manager 在）——直接读 manager 分支。
      const manager = state.session ? state.session.sessionManager : state.manager;
      branch = manager.getBranch();
    } else {
      const file = await this.resolveSessionFile(id);
      if (!file) {
        return { ok: false, error: { code: "internal", message: `history: session ${id} not found on disk` } };
      }
      const sdk = await this.sdkReady();
      branch = sdk.SessionManager.open(file, SESSION_DIR).getBranch();
    }
    const entries = [];
    let seq = 0;
    // HistoryEntry 形态：{event: SessionEvent, view?}——事件本体在 event 字段里。
    const push = (event) => entries.push({ event: { ...event, seq: seq++ } });
    this.translateBranch(branch, push);
    return { events: entries, hasMore: false };
  }

  /** pi 分支消息 → dsh SessionEvent 序列（持久化回放的翻译）。 */
  translateBranch(branch, push) {
    let turn = 0;
    for (const entry of branch) {
      if (entry.type !== "message") continue;
      const m = entry.message;
      if (!m || !Array.isArray(m.content)) continue;
      const text = m.content.filter((c) => c.type === "text").map((c) => c.text).join("");
      if (!text) continue;
      if (m.role === "user") {
        turn += 1;
        push({ type: "turn/start", time: Date.now(), data: { turn } });
        push({ type: "user/message", surfaceOp: "append", time: Date.now(), data: { content: [{ type: "text", text }], source: { kind: "user" } } });
      } else if (m.role === "assistant") {
        push({ type: "assistant/chunk", time: Date.now(), data: { turn, step: 1, chunk: { type: "block-start", index: 0, blockType: "text" } } });
        push({ type: "assistant/chunk", time: Date.now(), data: { turn, step: 1, chunk: { type: "text-delta", index: 0, text } } });
        push({ type: "assistant/chunk", time: Date.now(), data: { turn, step: 1, chunk: { type: "block-end", index: 0, block: { type: "text", text } } } });
        push({ type: "turn/end", time: Date.now(), data: { turn, reason: { kind: "completed" } } });
      } else if (m.role === "toolResult") {
        // 历史回放：toolResult 消息 → tool/call + tool/result 事件对（工具行渲染）。
        // pi 的 jsonl 里工具调用的入参在 assistant 的 toolCall 内容块上，回放时
        // 先发一个以结果反推的 call 事件（同名占位），再发 result。
        const callId = m.toolCallId || `call_replay_${turn}`;
        push({ type: "tool/call", time: Date.now(), data: { turn, step: 1, callId, name: m.toolName || "tool", arguments: "" } });
        push({ type: "tool/result", surfaceOp: "append", time: Date.now(), data: {
          turn, step: 1,
          message: {
            source: { kind: "tool", callId },
            content: [{ type: "tool-result", toolCallId: callId, content: [{ type: "text", text: String(text || "[tool]") }], isError: false }],
            role: "user",
            id: callId,
          },
          sourceEventSeqs: [],
        } });
      }
    }
  }

  async sessionModels(payload) {
    const state = await this.ensureSession(String(payload.sessionId)).catch(() => null);
    const groups = await this.modelCatalog();
    const current = state?.session?.model
      ? { provider: state.session.model.provider, model: state.session.model.id }
      : this.fallbackRoute(groups);
    return {
      current,
      routable: true,
      groups,
      failures: [],
    };
  }

  /**
   * llm.providers：设置页 provider 目录（真实宿主形态）。合并两路：
   * pi 内置目录的每个服务商一行（未配置即「休眠」行，是「添加」下拉的数据源），
   * models.json 里声明而目录没有的条目补 declared:true 的一行；
   * active = 该路由当前可服务（hasConfiguredAuth：models.json inline key /
   * auth.json / 注入的环境密钥任一成立）。
   */
  async llmProviders() {
    const [nativeRows, runtime] = await Promise.all([this.nativeCatalog(), this.runtime().catch(() => null)]);
    const piModels = this.readPiModels();
    const configured = piModels.providers || {};
    const displayNames = this.readDisplayNames();
    const providers = [];
    const seen = new Set();
    const pushRow = (id, displayName, isConfigured) => {
      if (!id || seen.has(id)) return;
      seen.add(id);
      providers.push({
        provider: id,
        displayName: (isConfigured ? displayNames[id] || displayName : displayName) || id,
        settingsNs: "llm-pi-ai",
        settingsPath: ["providers", id],
        active: Boolean(runtime && runtime.hasConfiguredAuth(id)),
        ...(isConfigured && !nativeRows.some((row) => row.id === id) ? { declared: true } : {}),
      });
    };
    // 内置目录在前（稳定的版本目录序），models.json 新增的排后面。
    for (const row of nativeRows) {
      pushRow(row.id, row.name, configured[row.id] !== undefined);
    }
    for (const [name, p] of Object.entries(configured)) {
      pushRow(name, (p && p.displayName) || name, true);
    }
    return { providers };
  }

  /**
   * llm.discoverModels：设置页「获取模型」。
   * 目录短路：注册表已描述的路由（内置目录或 models.json 已声明）直接用目录
   * 回答——带容量元数据且零网络，与 dsh 的 registry-first 语义一致；目录没有
   * 的路由按 baseURL 探测 OpenAI 兼容的 GET /models。失败以
   * model-discovery-failed 结构化返回，消息即页面展示的失败原因。
   */
  async llmDiscoverModels(payload) {
    const settingsNs = String(payload?.settingsNs ?? "");
    const provider = typeof payload?.provider === "string" && payload.provider ? payload.provider : undefined;
    const baseURL = typeof payload?.baseURL === "string" && payload.baseURL ? payload.baseURL : undefined;
    const api = typeof payload?.api === "string" && payload.api ? payload.api : undefined;
    const apiKey = typeof payload?.apiKey === "string" && payload.apiKey ? payload.apiKey : undefined;
    const discoveryError = (message) => ({
      ok: false,
      error: { code: "model-discovery-failed", message, details: { settingsNs } },
    });
    if (provider) {
      try {
        const runtime = await this.runtime();
        const models = runtime.getModels(provider) || [];
        if (models.length) {
          return {
            models: models.map((m) => ({
              id: m.id,
              ...(m.name && m.name !== m.id ? { name: m.name } : {}),
              ...(Number.isFinite(m.contextWindow) && m.contextWindow > 0 ? { contextWindow: m.contextWindow } : {}),
              ...(Number.isFinite(m.maxTokens) && m.maxTokens > 0 ? { maxTokens: m.maxTokens } : {}),
            })),
          };
        }
      } catch {
        // 注册表不可用则继续走网络探测
      }
    }
    if (!baseURL) {
      return discoveryError(provider
        ? `pi 没有服务商「${provider}」的目录条目，模型清单只能来自其端点：请填写 Base URL，或手动录入模型`
        : "请先填写 Base URL 再获取模型");
    }
    // 端点探测只对 OpenAI 兼容协议有意义（与 dsh 的 LISTABLE_PROTOCOLS 同口径）。
    if (api && api !== "openai-completions" && api !== "openai-responses") {
      return discoveryError(`协议「${api}」没有可读取的模型清单，请手动录入模型`);
    }
    const { models, error } = await this.discoverProviderModels(baseURL, apiKey);
    if (!models.length) return discoveryError(error || "端点未返回任何模型");
    return { models };
  }

  /** llm.models：dsh 的全量模型目录（provider 分组）。 */
  async llmModels() {
    return { groups: await this.modelCatalog(), failures: [] };
  }

  /**
   * 统一的会话附着：内存命中直接返回；冷会话从磁盘 attach
   * （SessionManager.open + buildSession），订阅事件并广播 subscribed。
   * 所有 per-session 方法（prompt/selectModel/models/rename/cancel）都走这里，
   * 保证“点开任意历史会话即可操作”。
   */
  async ensureSession(id) {
    const existing = this.sessions.get(id);
    if (existing) {
      // fork 出的子会话：注册时只有 manager，首用时补建 agent session。
      if (!existing.session && existing.manager) {
        const { session } = await this.buildSession(existing.cwd ?? ROOT, existing.manager);
        existing.session = session;
        existing.unsubscribe = session.subscribe((event) => this.translateEvent(id, event));
      }
      // models.json 在会话构建后变过（页面加服务商/改密钥）→ 换新 runtime。
      await this.refreshSessionRuntime(existing);
      return existing;
    }
    const file = await this.resolveSessionFile(id);
    if (!file) return null;
    const sdk = await this.sdkReady();
    const manager = sdk.SessionManager.open(file, SESSION_DIR);
    // 以分支长度续接 seq，推送帧接在回放事件之后。
    const branch = manager.getBranch();
    let replaySeq = 0;
    this.translateBranch(branch, () => replaySeq++);
    const turnCount = branch.filter((e) => e.type === "message" && e.message?.role === "user").length;
    const state = { session: null, unsubscribe: null, seq: replaySeq, turn: turnCount, streaming: null, cwd: manager.cwd ?? ROOT, modelsMtime: this.currentModelsMtime() };
    const { session } = await this.buildSession(state.cwd, manager);
    state.session = session;
    this.sessions.set(id, state);
    state.unsubscribe = session.subscribe((event) => this.translateEvent(id, event));
    this.pushMux({ type: "session/subscribed", sessionId: id, lastSeq: replaySeq - 1 });
    return state;
  }

  async prompt(payload) {
    const id = String(payload.sessionId);
    let state = this.sessions.get(id);
    if (!state) {
      state = await this.ensureSession(id);
      if (!state) {
        return { ok: false, error: { code: "session-not-found", message: `会话不存在：${id}`, details: { sessionId: id } } };
      }
    }
    const text = Array.isArray(payload.content)
      ? payload.content.filter((p) => p.type === "text").map((p) => p.text).join("")
      : "";
    if (!text) return { ok: false, error: { code: "internal", message: "empty prompt" } };
    // pi 的 AgentSession.prompt 接收纯字符串；turn 事件经 subscribe 翻译推送。
    state.seq += 1;
    this.pushEvent(state, id, { type: "user/message", surfaceOp: "append", data: { content: [{ type: "text", text }], source: { kind: "user" } } });
    state.session.prompt(text).catch((error) => {
      console.error("[pi-bridge] prompt failed:", error instanceof Error ? error.message : String(error));
    });
    return { accepted: true };
  }

  async cancel(payload) {
    const state = await this.ensureSession(String(payload.sessionId)).catch(() => null);
    if (state && typeof state.session?.abort === "function") {
      state.session.abort();
    }
    return { accepted: true };
  }

  async rename(payload) {
    const state = await this.ensureSession(String(payload.sessionId)).catch(() => null);
    if (!state || !state.session) return { ok: false, error: { code: "session-not-found", message: "rename: 会话不存在", details: { sessionId: String(payload.sessionId ?? "") } } };
    if (typeof state.session.setSessionName === "function") {
      state.session.setSessionName(String(payload.title || ""));
    }
    state.seq += 1;
    return { title: String(payload.title || ""), seq: state.seq };
  }

  /** dsh session.selectModel：provider/model 路由切换（冷会话先 attach）。 */
  async selectModel(payload) {
    const state = await this.ensureSession(String(payload.sessionId)).catch(() => null);
    if (!state || !state.session) {
      return { ok: false, error: { code: "session-not-found", message: `会话不存在：${String(payload.sessionId)}`, details: { sessionId: String(payload.sessionId ?? "") } } };
    }
    const provider = String(payload.provider ?? "").trim();
    const modelId = String(payload.model ?? "").trim();
    const runtime = await this.runtime();
    const model = runtime.getModel(provider, modelId);
    if (!model) return { ok: false, error: { code: "internal", message: `model not in catalog: ${provider}/${modelId}` } };
    try {
      await state.session.setModel(model);
    } catch (error) {
      // setModel 的鉴权失败（checkAuth 走会话 runtime）给结构化错误而不是裸 internal。
      return { ok: false, error: { code: "model-unavailable", message: error instanceof Error ? error.message : String(error), details: { provider, model: modelId } } };
    }
    return { selected: { provider, model: modelId } };
  }

  /** dsh session.fork：pi 原生 forkFrom（新会话文件带完整历史）。 */
  async forkSession(payload) {
    const srcId = String(payload?.sessionId ?? "");
    const state = await this.ensureSession(srcId).catch(() => null);
    if (!state) {
      return { ok: false, error: { code: "session-not-found", message: `fork 源会话不存在：${srcId}`, details: { sessionId: srcId } } };
    }
    const srcFile = await this.resolveSessionFile(srcId);
    if (!srcFile) {
      return { ok: false, error: { code: "session-not-found", message: "fork 源会话没有磁盘文件（空会话不可分叉）", details: { sessionId: srcId } } };
    }
    const sdk = await this.sdkReady();
    const cwd = state.cwd ?? ROOT;
    const childManager = sdk.SessionManager.forkFrom(srcFile, cwd, SESSION_DIR);
    const childId = String(childManager.getSessionId());
    // 按客户端契约注册子会话（不推 subscribed 帧——客户端 open 子会话时才
    // 经 session.history 拉取；此处仅保证后续 RPC 能找到它）。
    const childState = { session: null, unsubscribe: null, seq: 0, turn: 0, streaming: null, cwd, modelsMtime: this.currentModelsMtime() };
    this.sessions.set(childId, childState);
    childState.manager = childManager;
    // host 注册帧：分支带完整历史（非 blank），带 parentSessionId 供目录树关联。
    this.pushHost({
      type: "host/session-added",
      sessionId: childId,
      blank: false,
      parentSessionId: srcId,
      cwd,
    });
    void this.pushHostWorkspaceOf(childId);
    return { sessionId: childId };
  }

  /** dsh commands/execute（args:{agentId, line}）→ pi 原生能力映射。
   * 宿主语义：命令生命周期以 command/run + command/done 事件对广播（UI 的
   * 命令行渲染依据），执行结果同时在 RPC 返回值里携带。
   */
  async executeCommand(args) {
    const line = String(args?.line ?? "");
    const agentId = String(args?.agentId ?? "");
    const state = await this.ensureSession(agentId).catch(() => null);
    if (!state || !state.session) {
      return { ok: false, error: { code: "command-error", message: `命令需要已附着的会话（${agentId.slice(0, 8)}…）` } };
    }
    const match = /^\/([a-z][a-z0-9_-]*)(?=$|[\t\n\r ])/u.exec(line);
    const name = match ? match[1] : "";
    const rest = line.slice(match ? match[0].length : 0);
    const commandId = crypto.randomUUID();
    this.pushEvent(state, agentId, {
      type: "command/run",
      data: { commandId, name, args: rest.trim(), source: { kind: "user" } },
    });
    let outcome;
    try {
      const r = await this.runCommand(name, rest, state, agentId, commandId);
      if (r && r.ok === false) {
        outcome = { kind: "error", text: r.error?.message || "命令失败" };
      } else if (r && typeof r.kind === "string") {
        outcome = { kind: r.kind === "error" ? "error" : "success", text: r.text ?? "" };
      } else {
        outcome = { kind: "success", text: "" };
      }
    } catch (e) {
      outcome = { kind: "error", text: e instanceof Error ? e.message : String(e) };
    }
    this.pushEvent(state, agentId, {
      type: "command/done",
      data: { commandId, kind: outcome.kind, ...(outcome.text ? { text: outcome.text } : {}) },
    });
    if (outcome.kind === "error") {
      return { ok: false, error: { code: "command-error", message: outcome.text } };
    }
    return { kind: outcome.kind, text: outcome.text };
  }

  /** 命令分派（executeCommand 的 switch 体；compact 会补发 compaction 事件流）。 */
  async runCommand(name, rest, state, agentId, commandId) {
    const session = state.session;
    switch (name) {
      case "compact": {
        // pi 原生压缩 → dsh compaction 事务事件（UI 的 manual-compaction 渲染依据）。
        const result = await session.compact();
        const compactionId = crypto.randomUUID();
        const summaryText = result?.summary || "（无摘要）";
        this.pushEvent(state, agentId, { type: "compaction/start", data: { compactionId, sourceCommandId: commandId, turn: null } });
        this.pushEvent(state, agentId, {
          type: "compaction/summary",
          data: {
            compactionId,
            sourceCommandId: commandId,
            summary: [{ type: "text", text: summaryText }],
            shadowedRange: { start: 0, end: 0 },
            shadowedSeqs: [],
            shadowedTokenCount: result?.tokensBefore ?? 0,
            provider: session.model ? `${session.model.provider}/${session.model.id}` : "pi",
          },
        });
        // 压缩检查点：replacement user message 带 plugin source（客户端的 checkpoint 识别依据）。
        this.pushEvent(state, agentId, {
          type: "user/message",
          surfaceOp: "append",
          data: {
            content: [{ type: "text", text: summaryText }],
            source: { kind: "plugin", plugin: "compact", compactionId, sourceCommandId: commandId },
          },
        });
        this.pushEvent(state, agentId, { type: "compaction/end", data: { compactionId, result: result ?? undefined } });
        return { kind: "success", text: "已压缩会话上下文" };
      }
      case "clear":
        session.clearQueue?.();
        return { kind: "success", text: "已清空待发队列" };
      case "title":
      case "rename": {
        const title = rest.trim();
        if (!title) return { ok: false, error: { code: "command-error", message: "用法：/title <新标题>" } };
        session.setSessionName(title);
        return { kind: "success", text: `标题已设为 ${title}` };
      }
      case "model": {
        const spec = rest.trim();
        const runtime = await this.runtime();
        const slash = spec.split("/");
        if (slash.length === 2) {
          const model = runtime.getModel(slash[0], slash[1]);
          if (!model) return { ok: false, error: { code: "command-error", message: `目录中无此模型：${spec}` } };
          await session.setModel(model);
          return { kind: "success", text: `模型已切换：${spec}` };
        }
        const current = session.model ? `${session.model.provider}/${session.model.id}` : "未知";
        return { kind: "success", text: `当前模型：${current}（切换用 /model <provider>/<model>）` };
      }
      case "goal": {
        // /goal [动词|目标]：show/create/edit/pause/resume/clear + relentless/normal 模式切换。
        const arg = rest.trim();
        const goal = this.goals && this.goals.get(agentId);
        const fmt = (g, header) => `${header}\n目标：${g.objective}\n状态：${g.phase}${g.mode === "relentless" ? "（不完成不准停）" : ""} · 已推进 ${g.roundsStarted} 轮 / 上限 ${g.maxGoalRounds}`;
        if (!arg) {
          return goal
            ? { kind: "success", text: fmt(goal, "当前目标") }
            : { kind: "success", text: "当前没有目标。用法：/goal <目标> 创建；/goal relentless 切换强制完成模式。" };
        }
        if (arg === "clear") {
          if (!goal) return { kind: "success", text: "没有可清除的目标。" };
          await this.goalClear({}, agentId);
          return { kind: "success", text: "目标已清除。" };
        }
        if (arg === "pause") {
          if (!goal) return { kind: "error", text: "没有活动目标可暂停。" };
          await this.goalPause({}, agentId);
          return { kind: "success", text: "目标已暂停（/goal resume 继续）。" };
        }
        if (arg === "resume") {
          if (!goal) return { kind: "error", text: "没有目标可恢复。" };
          await this.goalResume({}, agentId);
          return { kind: "success", text: "目标已恢复推进。" };
        }
        if (arg === "relentless" || arg === "normal") {
          if (!goal) return { kind: "error", text: "没有目标可切换模式；先 /goal <目标> 创建。" };
          goal.mode = arg;
          goal.revision += 1;
          goal.updatedAt = Date.now();
          this.pushGoalProjection(agentId);
          if (arg === "relentless" && goal.phase === "paused") {
            goal.phase = "active";
            this.pushGoalProjection(agentId);
            setImmediate(() => this.goalDrive(agentId));
          }
          return { kind: "success", text: arg === "relentless" ? "已切换：不完成不准停（自动连续推进）。" : "已切换：普通模式（每轮后暂停等待确认）。" };
        }
        if (arg.startsWith("edit ")) {
          if (!goal) return { kind: "error", text: "没有目标可编辑。" };
          await this.goalEdit({ objective: arg.slice(5).trim() }, agentId);
          return { kind: "success", text: fmt(goal, "目标已更新") };
        }
        // 其余文本 = 创建新目标（已有未完成目标时提示先 clear）。
        if (goal && goal.phase !== "complete") {
          return { kind: "error", text: `已有进行中的目标（${goal.phase}）。/goal clear 后再创建，或 /goal edit <目标> 修改。` };
        }
        await this.goalCreate({ objective: arg, mode: "normal", maxGoalRounds: 100 }, agentId);
        const created = this.goals.get(agentId);
        return { kind: "success", text: fmt(created, "目标已创建，开始推进") };
      }
      default:
        return { ok: false, error: { code: "command-error", message: `pi 桥暂不支持命令 /${name}；可用：/compact /clear /title /model` } };
    }
  }

  // ── 事件翻译：pi 事件 → dsh SessionEvent → mux 帧 ─────────────────

  pushEvent(state, sessionId, event, view) {
    const full = { ...event, seq: state.seq, time: Date.now() };
    state.seq += 1;
    this.pushMux({ type: "session/event", sessionId, event: full, ...(view ? { view } : {}) });
  }

  // ── host 注册帧：工作区分组 / 会话摘要的热更新通道 ────────────────
  //
  // 客户端的工作区分组只从 host 通道的 host/workspace-changed、
  // host/session-added 等帧热更新；不发帧，新会话/分支在别的客户端视图里
  // 就一直是“未被任何工作区认领”→ 未分组。server.cjs 注入 onHostFrame。

  pushHost(frame) {
    if (typeof this.onHostFrame === "function") this.onHostFrame(frame);
  }

  /**
   * 任务通知：把目标完成/受阻推给 portal（portal 前端经 Tauri 发系统通知）。
   * 尽力而为：portal 未运行或不可达时静默丢弃，绝不影响会话本身。
   * @param {string} title - 通知标题。
   * @param {string} body - 通知正文。
   */
  notifyPortal(title, body) {
    const port = Number(process.env.PORTAL_PORT) || 3470;
    const controller = typeof AbortController === "function" ? new AbortController() : null;
    const timer = controller ? setTimeout(() => controller.abort(), 4000) : null;
    fetch(`http://127.0.0.1:${port}/api/notify`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title, body, source: "pi" }),
      signal: controller ? controller.signal : undefined,
    })
      .then((res) => { if (!res.ok) throw new Error(`HTTP ${res.status}`); })
      .catch(() => {})
      .finally(() => { if (timer) clearTimeout(timer); });
  }

  /** 目标进入终态时推系统通知（complete = 完成，blocked = 失败/受阻）。 */
  notifyGoalSettled(goal, outcome) {
    if (!goal) return;
    const objective = String(goal.objective || "").slice(0, 60);
    if (outcome === "complete") {
      this.notifyPortal("pi 任务完成 ✓", `${objective}（已推进 ${goal.roundsStarted} 轮）`);
    } else {
      const reason = goal.blockedReason && goal.blockedReason.message
        ? goal.blockedReason.message
        : "目标已受阻";
      this.notifyPortal("pi 任务失败 ✗", `${objective}：${reason}`);
    }
  }

  /** 推送某会话所属工作区的最新视图（workspace.list 重算后挑出所在组）。 */
  async pushHostWorkspaceOf(sessionId) {
    try {
      const { items } = await this.workspaceList();
      const view = items.find((i) => i.sessionIds.includes(String(sessionId)));
      if (view) this.pushHost({ type: "host/workspace-changed", workspace: view });
    } catch (error) {
      console.error("[pi-bridge] workspace frame failed:", error instanceof Error ? error.message : String(error));
    }
  }

  /** pi 工具结果（any）→ 展示文本：bash stdout / MCP content / 对象序列化。 */
  extractToolOutput(result) {
    if (result === null || result === undefined) return "";
    if (typeof result === "string") return result;
    if (Array.isArray(result?.content)) {
      return result.content
        .map((c) => (typeof c === "string" ? c : c?.type === "text" ? String(c.text ?? "") : JSON.stringify(c)))
        .join("");
    }
    if (typeof result.stdout === "string") return result.stdout;
    if (typeof result.output === "string") return result.output;
    if (typeof result.text === "string") return result.text;
    try {
      return JSON.stringify(result, null, 1).slice(0, 2000);
    } catch {
      return String(result);
    }
  }

  /** pi 流事件 → dsh 事件（MVP 词表）。 */
  translateEvent(sessionId, ev) {
    const state = this.sessions.get(sessionId);
    if (!state) return;
    switch (ev.type) {
      case "agent_start": {
        state.turn += 1;
        this.pushEvent(state, sessionId, { type: "turn/start", data: { turn: state.turn, trigger: { kind: "message", source: { kind: "user" } } } });
        break;
      }
      // pi 的 turn_start/turn_end/agent_settled/message_start 为过程性事件：
      // turn 边界由 agent_start/agent_end 翻译，块边界由增量路径自管。
      case "turn_start":
      case "turn_end":
      case "agent_settled":
      case "message_start":
        break;
      case "message_update": {
        // 增量路径：pi 流式时逐 delta 到达。首个 delta 先开块。
        const delta = ev.assistantMessageEvent && typeof ev.assistantMessageEvent.delta === "string" ? ev.assistantMessageEvent.delta : "";
        if (!delta) break;
        if (!state.streaming) {
          state.streaming = { text: "" };
          this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "block-start", index: 0, blockType: "text" } } });
        }
        state.streaming.text += delta;
        this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "text-delta", index: 0, text: delta } } });
        break;
      }
      case "message_end": {
        // pi 对 user/assistant 消息都发 message_end；只翻译 assistant。
        const msg = ev.message;
        if (!msg || msg.role !== "assistant") break;
        const full = Array.isArray(msg.content)
          ? msg.content.filter((c) => c.type === "text").map((c) => c.text).join("")
          : "";
        // provider 报错（401 等）：把错误可见化进会话流。
        if (msg.stopReason === "error") {
          const errText = `⚠ 模型调用失败：${msg.errorMessage || "unknown provider error"}`;
          // 有活动目标时，provider 失败即任务失败：推系统通知。无目标则静默——
          // 普通对话的偶发失败不该打扰。
          const activeGoal = this.goals && this.goals.get(sessionId);
          if (activeGoal && activeGoal.phase === "active") {
            this.notifyPortal("pi 任务失败 ✗", `${String(activeGoal.objective || "").slice(0, 60)}：${String(msg.errorMessage || "模型调用失败").slice(0, 120)}`);
          }
          this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "block-start", index: 0, blockType: "text" } } });
          this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "text-delta", index: 0, text: errText } } });
          this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "block-end", index: 0, block: { type: "text", text: errText } } } });
          break;
        }
        if (state.streaming) {
          // 已有增量流：收口当前块。
          const accumulated = state.streaming.text;
          state.streaming = null;
          this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "block-end", index: 0, block: { type: "text", text: full || accumulated } } } });
        } else {
          // 无增量（一次性返回）：合成完整块。
          this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "block-start", index: 0, blockType: "text" } } });
          if (full) this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "text-delta", index: 0, text: full } } });
          this.pushEvent(state, sessionId, { type: "assistant/chunk", data: { turn: state.turn, step: 1, chunk: { type: "block-end", index: 0, block: { type: "text", text: full } } } });
        }
        break;
      }
      case "tool_execution_start": {
        // 工具调用开始 → dsh 的 tool/call 事件（工具行渲染的依据）。
        const callId = ev.toolCallId || `call_${state.seq}`;
        state.activeCalls = state.activeCalls || new Map();
        state.activeCalls.set(callId, { name: ev.toolName || "tool", seq: state.seq + 1 });
        this.pushEvent(state, sessionId, {
          type: "tool/call",
          data: {
            turn: state.turn, step: 1, callId,
            name: ev.toolName || "tool",
            arguments: typeof ev.args === "string" ? ev.args : JSON.stringify(ev.args ?? {}),
          },
        }, { for: "call", view: { card: "terminal", title: ev.toolName || "tool" } });
        break;
      }
      case "tool_execution_update": {
        // 增量输出：MVP 忽略（终值在 end 里）。
        break;
      }
      case "tool_execution_end": {
        // 工具执行完成 → dsh 的 tool/result 事件。
        const callId = ev.toolCallId || "";
        const callInfo = (state.activeCalls && state.activeCalls.get(callId)) || { name: ev.toolName || "tool", seq: state.seq };
        if (state.activeCalls) state.activeCalls.delete(callId);
        const output = this.extractToolOutput(ev.result);
        const isError = Boolean(ev.isError);
        this.pushEvent(state, sessionId, {
          type: "tool/result",
          surfaceOp: "append",
          data: {
            turn: state.turn, step: 1,
            message: {
              source: { kind: "tool", callId },
              content: [{
                type: "tool-result",
                toolCallId: callId,
                content: [{ type: "text", text: output }],
                isError,
              }],
              role: "user",
              id: callId,
            },
            sourceEventSeqs: [callInfo.seq],
          },
        }, { for: "result", view: { card: "terminal", output: String(output).slice(0, 4000), exitCode: isError ? 1 : 0 } });
        break;
      }
      case "agent_end": {
        this.pushEvent(state, sessionId, { type: "turn/end", data: { turn: state.turn, reason: { kind: "completed" } } });
        // 正常收尾时 activeCalls 已被 tool_execution_end 清空；这里兜底
        // 清掉中止/异常路径留下的孤儿条目（否则只增不减）。
        if (state.activeCalls) state.activeCalls.clear();
        break;
      }
      default:
        break; // 未知 pi 事件：忽略（词表演进按需扩展）
    }
  }

  pushMux(frame) {
    if (typeof this.onMuxFrame === "function") this.onMuxFrame(frame);
  }
}

module.exports = { PiBridge, ROOT, AGENT_DIR, SESSION_DIR };
